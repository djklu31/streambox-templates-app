<?php

include_once("../sys/inc/phpsock.inc");
include_once("../encoder/inc/enc_label.php");
include_once("../decoder/inc/dec_label.php");

$dec_port = 1801;
$enc_port = 1802;

if (!isset($phpSend )){
	if (isset($encpt)) $phpSend = $encpt;
	else $phpSend = new CSendObject("127.0.0.1", $enc_port);
}






$linkabsname = '/usr/local/bin/usr/LinuxEncoder.exe';

$linkfname = "-";
if (is_link($linkabsname)){
	$linkfname = basename(readlink($linkabsname));
}

$fDE = 0;
$aa = strpos($linkfname, 'Encoder');
if (is_int($aa)) $fDE = 1;
$aa = strpos($linkfname, 'Decoder');
if (is_int($aa)) $fDE = 2;


$app_mode  = 0;
$num_multi = 4;

//include_once("inc/IXR_Library.inc");


$HAS_CDI = file_exists("/var/lib/avenir/conf/HAS_CDI");
$SYS_XML_FILE     = "/var/lib/avenir/sys.xml";
$OLD_ME_INDICATOR = "/var/lib/avenir/MULTI_ENC";
$OLD_MD_INDICATOR = "/var/lib/avenir/MULTI_DEC";


$encLabels = new EncLabels();
$decLabels = new DecLabels();


function setBool10(&$r,$name, $v){
	if ($v) $r[$name] = 1;
	else    $r[$name] = 0;
}


function getEncResult($phpSend, $cmd){
	$r = $phpSend->sendCommand($cmd);
	return $r['result'];
}

function setStrEncResult($phpSend, &$r, $name, $cmd){
	$r[$name] = getEncResult($phpSend, $cmd);
}

function setIntEncResult($phpSend, &$r, $name, $cmd){
	$r[$name] = intval(getEncResult($phpSend, $cmd));
}

$crypt_dict = array(
	 0 => ""
	,1 => "AES128"
	,2 => "AES192"
	,3 => "AES256"
	,4 => "GOST15"
);

$enc_cmd_list = array(
	 array(0, "signal", "get::inputsignal")
	,array(0, "bitrate", "get::INFO::C-BITRATE")
	,array(0, "dec_ip", "get::decoderip")
	,array(1, "port", "get::port")
	,array(0, "meta_title", "get::Meta_Slug")
	,array(1, "drop_cap", "get::INFO::DROP-CAP")

	//,array(1, "is_streaming", "get::isStreaming")
	//,array(1, "is_recording", "get::isRecording")

	,array(1, "crypt_state", "get::EncryptionState")
	,array(1, "crypt_warn", "get::EncryptionWarn")

	//,array(1, "cdi_addr", "get::CdiAddr")
	//,array(1, "cdi_port", "get::CdiPort")

	//,array(0, "", "")
	//,array(0, "", "")

);

$dec_cmd_list = array(
	 array(1, "port", "get::port")
	,array(0, "bitrate", "get::INFO::BITRATE")
	,array(1, "lost_pkts", "get::INFO::LOST")
	,array(1, "recov_pkts", "get::INFO::RECOV")
	,array(0, "meta_title", "get::INFO::METADATA::SLUG")
	,array(0, "src",        "get::INFO::METADATA::PRODUCER")
	,array(1, "output_cable","get::OutputCable") //CDI or SDI, (v>0)=>Connected, (v<0)=>Disconn, (v==0):unknown
);


if ($HAS_CDI){
	$enc_cmd_list[] = array(1, "cdi_port", "get::CdiPort");
	$dec_cmd_list[] = array(0, "cdi_addr", "get::CdiAddr");
	$dec_cmd_list[] = array(1, "cdi_port", "get::CdiPort");
}



////////////////////////////////////////////////////////////////////////

$app_mode_list = array(
	 0 => "N/A"
	,1 => "single-encoder"
	,2 => "single-decoder"
	,3 => "multi-encoder"
	,4 => "multi-decoder"
	,5 => "full-duplex"
	//,6 => "dual-encoder"
);


function get_app_mode(){
	//return 4; //test
	global $SYS_XML_FILE;
	global $OLD_ME_INDICATOR;
	global $OLD_MD_INDICATOR;
	if (file_exists($SYS_XML_FILE)){
		return get_app_mode_new();
	} else {
		return get_app_mode_old();
	}
}


function get_app_mode_old(){
	global $OLD_ME_INDICATOR;
	global $OLD_MD_INDICATOR;
	global $num_multi;
	global $fDE;
	if (file_exists($OLD_ME_INDICATOR)){
		$nEnc = intval(file_get_contents($OLD_ME_INDICATOR));
		if ($nEnc>0) $num_multi = $nEnc;
		return 3; //multi-enc
	} elseif (file_exists($OLD_MD_INDICATOR)){
		$nDec = intval(file_get_contents($OLD_MD_INDICATOR));
		if ($nDec>0) $num_multi = $nDec;
		return 4; //multi-dec
	} else {
		if ($fDE==1) return 1; //single-enc
		if ($fDE==2) return 2; //single-dec
		return 0;
	}
}


function get_app_mode_new(){
	//TODO: delete this line:
	return get_app_mode_old();

	global $SYS_XML_FILE;
	if (! file_exists($SYS_XML_FILE)) return 0;
	//TODO: implement new app method
	return 0;
}


////////////////////////////////////////////////////////////////////////


function makeEncLabel($encIdx){
	global $encLabels, $decLabels;
	$l = $encLabels->getLabel($encIdx);
	if (!$l) $l = "ENCODER" . $encIdx;
	return $l;
}

function makeDecLabel($appIdx){
	global $encLabels, $decLabels;
	$l = $decLabels->getLabel($appIdx);
	if (!$l) $l = "DECODER" . $appIdx;
	return $l;
}


function getEncStatus($encIdx, &$r, $phpSend=null){
	global $encLabels, $decLabels;
	global $enc_port, $dec_port;
	global $enc_cmd_list;
	//$r = array();

	$r['label'] = makeEncLabel($encIdx);

	if (! $phpSend)
		$phpSend = new CSendObject("127.0.0.1", $enc_port + $encIdx);
	$k = $phpSend->isConnected();
	setBool10($r, "is_online", $k);
	if (! $k) return $r;

	foreach($enc_cmd_list as $k){
		switch($k[0]){
		  case 0:
			setStrEncResult($phpSend, $r, $k[1], $k[2]);
			break;
		  case 1:
			setIntEncResult($phpSend, $r, $k[1], $k[2]);
			break;
		  case 2:
			break;
		}
	}
}


function getDecStatus($appIdx, &$r, $phpSend=null){
	global $encLabels, $decLabels;
	global $enc_port, $dec_port;
	global $dec_cmd_list;
	//$r = array();
	$r['label'] = makeDecLabel($appIdx);
	//
	if (! $phpSend)
		$phpSend = new CSendObject("127.0.0.1", $dec_port + $appIdx);
	$k = $phpSend->isConnected();
	setBool10($r, "is_online", $k);
	if (! $k) return $r;
	//
	foreach($dec_cmd_list as $k){
		switch($k[0]){
		  case 0:
			setStrEncResult($phpSend, $r, $k[1], $k[2]);
			break;
		  case 1:
			setIntEncResult($phpSend, $r, $k[1], $k[2]);
			break;
		  case 2:
			break;
		}
	}
}


class MultiAppMan {

	function __construct(){
	}

	function __destruct(){
	}


	function getCmdList_url($_URL){
		$upl = explode("/", $_URL);
		//$l = count($upl);
		//if ($l>=1 && ! $upl[$l-1]) unset($upl[$l-1]);
		//$upl = array_values($upl); // renumber

	}


	function handleHTTPRequest($_URL, $encpt){
		global $JSON_ENC_OPT ;
		global $enc_port;
		global $fDE;
		global $num_multi;
		global $phpSend;

		if ($encpt) $phpSend = $encpt;
		if (isset($_POST['c']) && $_POST['c']){
			$c = json_decode($_POST['c'], true);
			if (!isset($c["command"])){
				$this->output_error_json(-1, "invalid command");
				return;
			}
			$cmd = $c["command"];
			switch($cmd){
			  case "apply":
				$acode = $c["code"];
				if (!$acode) $acode = "";
				$acode = $acode.trim();
				if (!$acode){
					$this->output_error_json(-1, "no code");
					break;
				}
				$phpSend->sendCommand("set::Feature::" . $acode);
				$this->output_error_json(0, "applied");
				break;
			}
			exit;
		} else {
			if (0){
				$mode = 0; // 1:enc 2:dec 3:menc 4: mdec
				$er = ["result_code"=>1, "message"=>"no"];
				//
				if (file_exists('/var/lib/avenir/MULTI_ENC')){
					$mode = 2;
				} elseif (file_exists('/var/lib/avenir/MULTI_DEC')){
					$mode = 3;
				} else {
					if ($fDE==2) $mode = 2;
				}
			}

			$r1 = array();

			$rr = array();
			$app_mode = get_app_mode();
			$rr['app_mode'] = $app_mode;
			//
			if (in_array($app_mode, array(3, 4))){
				$rr['num_multi_instances'] = $num_multi;
			}

			$r1['current_conf'] = $rr;

			switch ($app_mode){
			  case 1:
				$cl = array();
					$cr = array();
					getEncStatus(0, $cr, null);
					$cl[] = $cr;
				$r1['apps_status'] = $cl;
				break;
			  case 2:
				$cl = array();
					$cr = array();
					getDecStatus(1, $cr, null);
					$cl[] = $cr;
				$r1['apps_status'] = $cl;
				break;
			  case 3:
				$cl = array();
				for($i=0; $i<$num_multi; $i++){
					$cr = array();
					getEncStatus($i, $cr, null);
					$cl[] = $cr;
				}
				$r1['apps_status'] = $cl;
				break;
			  case 4:
				$cl = array();
				for($i=0; $i<$num_multi; $i++){
					$cr = array();
					getDecStatus($i, $cr, null);
					$cl[] = $cr;
				}
				$r1['apps_status'] = $cl;
				break;
			}


			//echo json_encode($rr, $JSON_ENC_OPT);
			//$r1 = array();
			//$r1['current_conf'] = $rr;

			echo json_encode($r1, $JSON_ENC_OPT);
			exit;
		}
	}


	function output_error_json($n, $msg, $e=1){
		global $JSON_ENC_OPT ;
		//$JSON_ENC_OPT = JSON_PRETTY_PRINT;
		echo json_encode(["result_code"=>$n, "message"=>$msg], $JSON_ENC_OPT);
		if ($e) exit;
	}


}




?>
