<?php

include_once("IXR_Library.inc");
//include_once("inc/decipidtable.php");
include_once("lnx_encdecswitch.inc");

define("_PF_TYPE_STR"      , 0);
define("_PF_TYPE_INT"      , 1);
define("_PF_TYPE_SUB_INT"  , 2);
define("_PF_TYPE_ZERO_ONE" , 3);
define("_PF_TYPE_ON_OFF  " , 4); // no longer used
define("_PF_TYPE_INT_RANGE", 5);
define("_PF_TYPE_CUSTOM"   , 6);

define("_PF_ERR_OBJ", null);


function GET_PF_TYPE_NAME($v){
	switch($v){
	  case 0: return "PF_TYPE_STR";
	  case 1: return "PF_TYPE_INT";
	  case 2: return "PF_TYPE_SUB_INT";
	  case 3: return "PF_TYPE_ZERO_ONE";
	  case 4: return "PF_TYPE_ON_OFF";
	  case 5: return "PF_TYPE_INT_RANGE";
	  case 6: return "PF_TYPE_CUSTOM";
	  default:return "PF_TYPE_STR";
	}
}



class PresetField {
	var $pftype;
	var $cname;
	var $label;
	var $cmd_base;
	var $default_value;
	var $desc = "";
	var $value_type;
	var $_custom_getcmd_ = null;
	var $_should_trim = 1;
	var $_unsupported_result_ok_ = 0;
	var $_isHD = 1;
	var $_ret_on_err = 0;
	var $v;
	var $_err = 0;
	var $_need_restart = 0;
	var $_read_only = 0;
	var $_cname_is_getcmd = 0;
	var $_skip_in_preset = 0;

	var $_set_cmd_  = null;
	var $_set_cmds_ = null;
	var $_set_ex_cmd_  = null;
	var $_get_ex_cmd_  = null;
	var $val_set = [];
	var $label_list = array();

	function __construct($cn, $l, $cmd, $dv){
		$this->pftype   = _PF_TYPE_STR;
		$this->cname    = $cn;
		$this->label    = $l;
		$this->cmd_base = $cmd;
		$this->default_value = $dv;
		$this->v             = $dv;
	}

	function getCmd(){
		if ($this->_custom_getcmd_) return $this->_custom_getcmd_;
		if ($this->_cname_is_getcmd) return $this->cname;
		return "get::" . $this->cmd_base ;
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		return "set::" . $this->cmd_base . "::" . ($v) ;
	}

	function setCmds($v){
		if ($this->_set_cmds_) return ($this->_set_cmds_)($v);
		$r = [];
		$s = $this->setCmd($v);
		if ($s) $r[] = $s;
		return $r;
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		$this->v = $s;
		return $s;
	}

	function _parse_int($s, $on_err=0){
		$v = intval($s);
		$this->v = $v;
		return $v;
	}

	function getLabelList(){
		return $this->label_list;
	}

	function setLabelList($l){
		$this->label_list = $l;
	}

	function return_on_err($on_err=0){
		$e = $on_err;
		if ($on_err==0) $e = $this->_ret_on_err;
		switch ($e){
		  case 0:
			return $this->default_value;
		  case 1:
			return _PF_ERR_OBJ;
		  default:
			return $this->default_value;
		}
	}

	function _is_in_range($v){
		return 1;
	}

	function __destruct() {
		//parent::__destruct();
	}


};

class PresetField_STR extends PresetField {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
	}
}

class PresetField_STR_RO extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->_read_only = 1;
	}
}

class PresetField_CUSTOM extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_CUSTOM;
	}
}

class PresetField_CUSTOM_RO extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_CUSTOM;
		$this->_read_only = 1;
	}
}

class PresetField_INT extends PresetField {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_INT;
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		$v = $this->_parse_int($s);
		if (! $this->_is_in_range($v)){
			$this->_err = 2;
			$this->v = $this->return_on_err();
			return $this->return_on_err();
		}
		return $v;
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if (! $this->_is_in_range($v)){
			return "";
		}
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		return "set::" . $this->cmd_base . "::" . strval($v) ;
	}
};


class PresetField_INT_RO extends PresetField_INT {
	function __construct($cn, $l, $cmd, $dv, $cname_is_cmd=0){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_INT;
		$this->_read_only = 1;
		$this->_cname_is_getcmd = $cname_is_cmd;
	}
}


class PresetField_INT_RANGE extends PresetField_INT {
	var $low;
	var $high;
	function __construct($cn, $l, $cmd, $dv, $low, $high){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_INT_RANGE;
		$this->low  = $low;
		$this->high = $high;
		//$this->setLabelList($lv);
	}

	function _is_in_range($v){
		if ($v>=$this->low && $v<=$this->high) return 1;
		return 0;
	}

};


class PresetField_SUB_INT extends PresetField_INT {
	function __construct($cn, $l, $cmd, $dv, $subset, $lv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_SUB_INT;
		$this->val_set = $subset;
		$this->setLabelList($lv);
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		$v = $this->_parse_int($s);
		if (! in_array($v, $this->val_set)){
			$this->_err = 2;
			$this->v = $this->return_on_err();
			//$this->v = $this->default_value;
			return $this->return_on_err();
		}
		return $v;
	}

	function _is_in_range($v){
		if (in_array($v, $this->val_set)) return 1;
		return 0;
	}

};


class PresetField_ZERO_ONE extends PresetField_SUB_INT {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv, [0,1], Array());
		$this->pftype = _PF_TYPE_ZERO_ONE;
	}
};


// basically boolean but accessor use ON/OFF, (cf. use get::***=>"OFF", set::***::OFF)
class PresetField_ON_OFF extends PresetField_ZERO_ONE {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv, [0,1], Array());
		$this->pftype = _PF_TYPE_ZERO_ONE;
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		if ( strcasecmp($s, "ON")==0) return 1;
		if ( strcasecmp($s, "OFF")==0) return 0;
		return $this->return_on_err();
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if (! $this->_is_in_range($v)){
			return "";
		}
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		switch ($v){
		  case 0:
			return "set::" . $this->cmd_base . "::" . "OFF" ;
			break;
		  case 1:
			return "set::" . $this->cmd_base . "::" . "ON" ;
			break;
		}
		return "";
	}

};






########################################

function get_sys_ver($pf=null, $encp=null){
	$AVESYSVERFILE='/var/lib/avenir/SYS_VERSION';
	if (file_exists($AVESYSVERFILE)){
		$f = fopen($AVESYSVERFILE,'r');
		if ($f){
			$AVE_VER = fread($f,1000);
			fclose($f);
		}
		return trim($AVE_VER) ;
	}
	return "N/A";
}

function get_SN($pf=null, $encp=null){
		$conn = new IXR_Client('http://localhost:1912/');
		$r = $conn->query('getSN');
		if ($r) return $conn->getResponse();
		return "N/A";
}

$inf_sys_ver   = new PresetField_STR_RO("sys_ver","Systerm Version","","");
$inf_sys_sn    = new PresetField_STR_RO("sys_sn", "Systerm Serial", "","");
$inf_sys_isdec = new PresetField_ZERO_ONE("sys_is_dec", "is decoder?", "", 0);

//$inf_sys_ver->_get_ex_cmd_ = function($pf, $e){ return get_sys_ver($pf,$e) ; };
$inf_sys_ver->_get_ex_cmd_ = "get_sys_ver"; // it's the way to set function pointer inn php ?
$inf_sys_sn->_get_ex_cmd_ = function ($pf, $e){
	$conn = new IXR_Client('http://localhost:1912/');
	$r = $conn->query('getSN');
	if ($r) return $conn->getResponse();
	return "";
};

$inf_sys_isdec->_get_ex_cmd_ = function ($pf, $e){
	exec("readlink -f /usr/local/bin/usr/LinuxEncoder.exe | grep -q Decoder", $n, $o);
	return ($o==0) ? 1 : 0 ;
};











$readonlyList = [
	 $inf_sys_ver
	,$inf_sys_sn
	,$inf_sys_isdec
];
foreach($readonlyList as $i){ $i->_read_only = 1; }


$pf_base_set = [
	 $inf_sys_ver
	,$inf_sys_sn
	,$inf_sys_isdec
];


$PRESET_CAT_LIST_INFO = [
	"sys_is_dec"
];

$PRESET_CAT_LIST_VER = [
	 "sys_ver"
	,"sys_sn"
];



$PRESET_CAT_LIST_DICT = [
	 1024 => $PRESET_CAT_LIST_INFO 
	,4096 => $PRESET_CAT_LIST_VER
];

$PRESET_CAT_BIT_DICT = [
	 "status"    => 1024
	,"version"   => 4096
];



class PFMan {
	var $cat_list = array();

	function __construct(){
		global $PRESET_CAT_BIT_DICT;
		$this->cat_list = array_keys($PRESET_CAT_BIT_DICT);
	}

	function getCatNameList(){
		return $this->cat_list;
	}


	function getCmdList_url($_URL){
		global $PRESET_CAT_BIT_DICT ;
		#$_URL = $_REQUEST["_url"];
		$upl = explode("/", $_URL);
		$l = count($upl);
		if ($l>=1 && ! $upl[$l-1]) unset($upl[$l-1]);

		$l = count($upl);
		if (!$l){
			// no category name
			return null;
		}
		$catname = $upl[0];

		if (! in_array($catname, $this->cat_list)){
			// not exists in cat_name_list
			return null;
		}
		$catBit = $PRESET_CAT_BIT_DICT[$catname];
		if (!$catBit){
			// not exists in cat_name_list
			return null;
		}
		//print "$catBit \n";

		return $this->getPFList($catBit);
	}


	function getPFList($catBit){
		global $pf_base_set;
		global $PRESET_CAT_LIST_DICT ;

		$r = [];
		for($b=1; $b <= 65536; $b<<=1){
			if (!($b & $catBit)) continue;
			$pf_names = $PRESET_CAT_LIST_DICT[$b];
			foreach($pf_names as $i){
				foreach($pf_base_set as $j){
					if ($i == $j->cname){
						$r[] = $j;
						break;
					}
				}
			}
		}
		//echo count($r), "\n";
		return $r;
	}



	function getAllCmds(){
		return $this->getPFList(0xFFFFFFFF);
	}




	function getCmdList_test($t){
		//TODO: $t: flag to choose category
		global  $pf_vbr ,$pf_meta_tit ,$pf_meta_loc ,$pf_meta_rep ,$pf_meta_drm  ;
		global $pf_bitrate
			,$pf_framerate
			,$pf_keyframe
			,$pf_colorProf
			,$pf_colorSpace
			,$pf_framerate
			,$pf_vbr
			,$pf_fec
		;

		return [
			 $pf_bitrate
			,$pf_framerate
			,$pf_keyframe
			,$pf_colorProf
			,$pf_colorSpace
			,$pf_framerate
			,$pf_vbr
			,$pf_fec

			,$pf_meta_tit
			,$pf_meta_loc
			,$pf_meta_rep
			,$pf_meta_drm
		];
	}

	function fetchResults($encpt, $cmdlist){
		$r = [];
		if (!$cmdlist) $cmdlist = [];
		foreach ($cmdlist as $i){
			if ($i->_get_ex_cmd_){
				$v = ($i->_get_ex_cmd_)($i, $encpt);
			} else {
				$rr = $encpt->sendCommand($i->getCmd());
				$rr = $rr['result'];
				$v = $i->parse($rr);
			}
			$_item = [
				"cname" => $i->cname
				,"type" => $i->pftype
				,"label" => $i->label
				,"val" => $v
			];
			if ($i->pftype==_PF_TYPE_SUB_INT){
				$_item["sub_values"] = $i->val_set;
			}
			$vlist = $i->getLabelList();
			if ($vlist){
				$_item["val_labels"] = $vlist ;
			}
			$_item["read_only"] = $i->_read_only;

			if ($i->pftype==_PF_TYPE_INT_RANGE){
				$_item["vmin"] = $i->low ;
				$_item["vmax"] = $i->high ;
			}

			$r[] = $_item;
		}
		return $r;
	}


	function setAll($encpt, $vallist){
		$n = 0;
		$cmdlist = $this->getAllCmds();
		$cmdDict = [];
		foreach ($cmdlist as $i) $cmdDict[$i->cname] = $i;

		foreach ($vallist as $i){
			$cname = $i["cname"];
			$v     = $i["val"  ];
			if (!$cname) continue;
			$pf = $cmdDict[$cname];
			if (! $pf) continue;
			//print "$cname => $v \n";
			//$v = $pf->parse($v); // no need to parse, as JSON already transform type
			// if ($v is not valid) continue;
			if ($pf->_set_ex_cmd_){
				($pf->_set_ex_cmd_)($pf, $encpt, $v);
				//$n++;
				continue;
			}
			$cmds = $pf->setCmds($v);
			//echo "cmd: ", $cmd, "\n";
			if (! $cmds) continue;
			foreach($cmds as $cmd)
				$encpt->sendCommand($cmd);
			$n++;
		}
		return $n;
	}

	function wait4restarting($encpt){
		$isRestarting = 0;
		$nWaits = 0;
		while (1){
			$r = $encpt->sendCommand("isrestarting"); 
			switch($r['result']){
			  case "unsupported":
				$isRestarting = -1;
				usleep(300000);
				break;
			  case 1:
				$isRestarting = 1;
				$nWaits++;
				break;
			  case 0:
				$isRestarting = 0;
				break;
			  default:
				$isRestarting = -1;
				break;
			}
			////
			if ($isRestarting==0 || $isRestarting==-1 || $nWaits>800){
				break;
			}
			usleep(200000);
		}
	}


	function action($encpt, $alist){
		global $pullobj;
		$r = 0;
		$enccmd_list=[];
		foreach ($alist as $a){
			if (in_array($a, $enccmd_list)){
				// $encpt->sendCommand($a);
				continue;
			}elseif ($a=="switch_to_enc"){
				// TODO:
				switchto("ENCODER");
				continue;
			}elseif ($a=="switch_to_dec"){
				// TODO:
				switchto("DECODER");
				continue;
			}
			if (preg_match("/^msleep:(\\d+)$/", $a, $m)){
				$t = intval($m[1]);
				if ($t>0 && $t<=10*1000) usleep($t*1000);
			}
		}
		return $r;
	}


};


function _test_pf_category_integration_test(){
	global $PRESET_CAT_LIST_DICT;
	global $pf_base_set;
	foreach ([1,2,4,8,32,64,128,256] as $i){
		print "\ncategory $i ...\n";
		$title_list = $PRESET_CAT_LIST_DICT[$i];
		//print_r($title_list);
		foreach($title_list as $j){
			$_found = 0;
			$cname = $j;
			print("checking $cname ..\n");
			foreach($pf_base_set as $k){
				if ($cname == $k->cname){
					$_found = 1;
					break;
				}
			}

			if (!$_found){
				print("\t##ERR: cat[$i] $cname Not Found\n");
			}

		}

	}
}



# _test_pf_category_integration_test();


function _test_check_global_SERVER_for_URLPARAM(){
	print "\n";
	print_r($_SERVER["REDIRECT_URL"]);
	print "\n";
	print_r($_SERVER["REDIRECT_QUERY_STRING"]);
	print "\n";
	print_r($_SERVER["QUERY_STRING"]);
	print "\n";
	print_r($_SERVER["REQUEST_URI"]);
	print "\n";
	print_r($_REQUEST);
	print "\n";
	print_r($_REQUEST["_url"]);
	print "\n";
	$_URL = $_REQUEST["_url"];
	$up = explode("/", $_URL);
	print_r($up);
	print "\n";
	print_r($_SERVER);
}



//$cat_list = [ "status", "video", "audio", "network", "transport", "metadata", "encryption", "presets" ];



// encoder/status
// encoder/video
// encoder/audio
// encoder/network
// encoder/transport
// encoder/metadata
// encoder/encryption
// encoder/presets
// encoder/preview/JPG
// encoder/preview/BMP
// encoder/features
// encoder/features/new
// encoder/action




/*********************************************************************************
 RFC2253 (UTF-8 String Representation of Distinguished Names):

String  X.500 AttributeType
------------------------------
CN      commonName
L       localityName
ST      stateOrProvinceName
O       organizationName
OU      organizationalUnitName
C       countryName
STREET  streetAddress
DC      domainComponent
UID     userid
DN      (Distinguished Name) (ex. "DC=gp,DC=gl,DC=google,DC=com")

What does the string from that query mean?

The string ("CN=Dev-India,OU=Distribution Groups,DC=gp,DC=gl,DC=google,DC=com")
*********************************************************************************/


//if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {}
/*
CYGWIN_NT-5.1
Darwin
FreeBSD
HP-UX
IRIX64
Linux
NetBSD
OpenBSD
SunOS
Unix
WIN32
WINNT
Windows
*/


?>
