<?php

include_once("http-response-code.php");
include_once("IXR_Library.inc");
//include_once(dirname(__FILE__) . "/IXR_Library.inc");


$sConfigPath = __DIR__ . '/../../data/config.xml';
$accounts_xml_path = __DIR__ . '/../../data/accounts.xml';

for ($i=0; ($i<5 && !is_readable($sConfigPath)); $i++){
	$_kk = "";
	for($j=0; $j<$i; $j++) $_kk .= "/.." ;
	$sConfigPath       = __DIR__ . $_kk . '/../../data/config.xml';
	$accounts_xml_path = __DIR__ . $_kk . '/../../data/accounts.xml';
}
$sConfigPath = realpath($sConfigPath);
$accounts_xml_path = realpath($accounts_xml_path);
if (!is_readable($sConfigPath)) $sConfigPath = "/tmp/config.xml";
if (!is_readable($accounts_xml_path)) $accounts_xml_path = "/tmp/accounts.xml";
// echo $sConfigPath , "\n";
// echo $accounts_xml_path , "\n";


$aConfig = getSystemConfig($sConfigPath);



class AuthMan {

	var $errCodeTable  = array(
		 0 => "authorized"
		,1 => ">Incorrect login, please try again."
		,2 => "Application is offline. Please relaunch the App"
		,3 => ""
		,4 => ""
		,5 => "DoS detected: too much attempts in seconds."
		,6 => "Account locked: too many login attempts. Please try again a few minutes later."
		,7 => "Password expired"
		,8 => "Session Timeout"
		,9 => ""
	);

	function handleHTTPRequest($_URL ){
		global $JSON_ENC_OPT ;

		$aOK = $this->start();
		if ($aOK){
			// already authorized
		}

		if (isset($_POST['c']) && $_POST['c']){

			$c = json_decode($_POST['c'], true);
			if (!isset($c["command"])){
				$this->output_error_json(-1,"no command???");
				return;
			}

			$cmd = $c["command"];

			switch($cmd){
			  case "test":
				break;
			  case "auth":
				//$this->output_error_json(-3, json_encode($c)); return;
				//setSession($c["userID"], $c["pwd"]);
				$this->_auth($c["userID"], $c["pwd"]);

				break;
			  case "fail":
				http_response_code(401); //unauthorized
				break;
			  case "logout":
				$this->logout();
				return;
				break;
			  default:
				return;
				break;
			}


			$this->output_error_json(-1,"OK");
			return;
		}

		//$this->notAuthErr(10, "test");
		//echo "1233";

		if ($aOK){
			//http_response_code(200);
			$this->output_auth_err(0);
		} else {
			http_response_code(401); //unauthorized
		}

	}

	function logout(){
		include("session.php"); 
		if (session_start()) {
			session_unset();
			session_destroy();
		}
		$this->output_auth_err(0, "logout");
	}


	function redirect($location){
		header('Location: '.$location);
	}


	function isAuthorized(){
		return $this->start();
	}

	function notAuthErr($n, $msg){
		http_response_code(401); //unauthorized
		$this->output_error_json($n, $msg);
	}

	function output_auth_err($n){
		if ($n<0) $n = -$n;
		$this->output_error_json(-$n, $this->errCodeTable[$n], 0);
	}

	function output_error_json($n, $msg, $e=1){
		global $JSON_ENC_OPT ;
		//$JSON_ENC_OPT = JSON_PRETTY_PRINT;
		echo json_encode(["result_code"=>$n, "message"=>$msg], $JSON_ENC_OPT);
		if ($e) exit;
	}

	function start(){
		startSession();

		if (!array_key_exists('auth', $_SESSION) ||
		    (array_key_exists('auth', $_SESSION) && ($_SESSION['auth'] != true))
		){
			return 0;
		}
		else {
			$_SESSION['is_linux_encoder'] = true;
			return 1;
		}
	}


	function _auth($username, $password){
		// $username = $_POST['username'];
		// $password = $_POST['password'];
		global $aConfig;

		if (isset( $_SESSION['_autherr']) && isset( $_SESSION['_autherrt'] )){
			$nerr = $_SESSION['_autherr'];
			$ldate = strtotime($_SESSION['_autherrt']);
			$dd = time() -$ldate;
			if ($nerr>7){
				if (0 && $dd<3*60){ //still locked for 3 min
					$this->output_auth_err(6);
					exit;
				} else { // reset
					$_SESSION['_autherr'] = 0;
				}
			}
		}



		if (setSession($username, $password)) { // auth succeeded
			unset($_SESSION['_autherr']);
			if (isset($_SESSION['remaindays']) && $_SESSION['remaindays']>0
				&& ($aConfig['uexpdays']-$_SESSION['remaindays']) >= $aConfig['warndays']
				&& $aConfig['warn30']
			){
				$this->output_error_json(0, 
					"Password will be expired in ". $_SESSION['remaindays']
					." days, please change password." );
				exit;
			}
			$this->output_auth_err(0);
			exit;
		} else {
			if (isset($_SESSION['lockstate'])){
				if ($_SESSION['lockstate']==2){
					$this->output_auth_err(5);
				} elseif ($_SESSION['lockstate']==3){
					$this->output_auth_err(6);
				}
				sleep(3);
				exit;
			}

			$a = $_SESSION['_autherr'];
			if (!$a){
				$_SESSION['_autherr'] = 1; 
				$_SESSION['_autherrt'] = date("Y-m-d H:i:s"); 
			}
			else {
				$_SESSION['_autherr'] += 1; 
				$_SESSION['_autherrt'] = date("Y-m-d H:i:s"); 
			}

			sleep(3);

			if (isset($_SESSION['remaindays'])){
				if ($_SESSION['remaindays']==-1){
					$this->output_auth_err(7); // 90 days
					exit;
				}
			}

			$this->output_auth_err(1);
			exit;
		}


	}

};






function _getDeviceIP(){
	#global $aConfig;
	global $aDeviceTypes;
	$r = "127.0.0.1";
	$phpSend = new CSendObject('127.0.0.1', $aDeviceTypes['encoder']);
	if (@ startsWith($_SERVER['REQUEST_URI'],'/remoteNode/')){
		if($phpSend->isConnected()){
			$reply = $phpSend->sendCommand("get::decoderip");
			return $reply['result'];
		}
	}
	return $r;
}


function getSystemConfig($sFilePath){
	global $_WEBUI_VER;
	$dom = new domdocument();
	$aConfig = array();
	$webui_ver = $_WEBUI_VER;
	//Create config file if not exist.
	if(!file_exists($sFilePath)){
		$dom = new domdocument('1.0','UTF-8');
		$dom->formatOutput = true;
		$root = $dom->createElement('config');
		$root->setAttribute('sb_install_dir','/usr/local/bin');
		$root->setAttribute('actl3_default','/var/www/avenir/ACTL3');
		$root->setAttribute('device_ip','127.0.0.1');
		$root->setAttribute('platform','windows'); //Choices are 'osx' | 'windows' | 'unknown'
		$root->setAttribute('webui_ver', $webui_ver);
		$root->setAttribute('is3D','0');
		$dom->appendChild($root);

		$decoder = $dom->createElement('decoder');
		$decoder->setAttribute('sb_session_timeout','5000'); //in seconds
		
		$webui = $dom->createElement('webui');
		$webui->setAttribute('login_autofill', false);
		$root->appendChild($decoder);
		$root->appendChild($webui);
		if($dom->save($sFilePath) === false){
			print 'Cannot create file at '.$sFilePath;
			exit(0);
		}
	}

	if($dom->load($sFilePath)) {
		$nConfig = $dom->getElementsByTagName('config')->item(0);
		$nDecoder = $dom->getElementsByTagName('decoder')->item(0);
		$nWebUI = $dom->getElementsByTagName('webui')->item(0);
		$aConfig['sb_install_dir'] = $nConfig->getAttribute('sb_install_dir');
		$aConfig['actl3_default'] = $nConfig->getAttribute('actl3_default');
		$aConfig['device_ip'] = $nConfig->getAttribute('device_ip');
		$aConfig['platform'] = $nConfig->getAttribute('platform');
		$aConfig['webui_ver'] = $webui_ver;
		$aConfig['warn30'] = intVal($nConfig->getAttribute('warn30'));
		$aConfig['uexp90'] = intVal($nConfig->getAttribute('uexp90'));
		$warndays = intval($nConfig->getAttribute('warndays'));
		$uexpdays = intval($nConfig->getAttribute('uexpdays'));
		if ($warndays<=0) $warndays = 30;
		if ($uexpdays<=0) $uexpdays = 90;
		$aConfig['warndays'] = $warndays;
		$aConfig['uexpdays'] = $uexpdays;
		$aConfig['is3D'] = (bool) intval($nConfig->getAttribute('is3D'));
		$aConfig['sb_session_timeout'] = intval($nDecoder->getAttribute('sb_session_timeout'));
		$aConfig['login_autofill'] = $nWebUI ? $nWebUI->getAttribute('login_autofill') : "";
		$aConfig['is_enc_dec_only'] = file_exists("/var/lib/avenir/ENCODER_ONLY") ? 1 : NULL;
		$aConfig['is_enc_dec_only'] = file_exists("/var/lib/avenir/DECODER_ONLY") ? 2 : $aConfig['is_enc_dec_only'] ;

	} else {
		print 'Cannot load config file at '.$sFilePath;
		exit(0);
	}

	// patch for remoteNode
	//$aConfig['device_ip'] = _getDeviceIP();


	return $aConfig;
}


function setSessTimeout($configPath, $to){
	$to = intval($to);
	$dom = new domdocument();
	if($dom->load($configPath)) {
		$dom->formatOutput = true;
		$conf = $dom->getElementsByTagName('config')->item(0);
		if ($to>=0){
			$dec = $dom->getElementsByTagName('decoder')->item(0);
			$dec->setAttribute('sb_session_timeout', "".$to); //in seconds
		}
		$dom->save($configPath);
	}
}


function _doAuth($username, $password){
	global $accounts_xml_path;
	$aResult = false;
	$dom = new domdocument();
	if($dom->load($accounts_xml_path)) {
		$users = $dom->getElementsByTagName('user');
		foreach($users as $user) {
			if($aResult === false && strtolower($user->getAttribute('username')) == strtolower($username) && $user->getAttribute('pass') == $password) {
				$aResult['name'] = $user->getAttribute('name');
				$aResult['username'] = $user->getAttribute('username');
				$aResult['type'] = $user->getAttribute('type');
				$now = date('Y.m.d H:i:s');
				$user->setAttribute('lastaccess',$now);
				$dom->save($accounts_xml_path);
			}
		}
	} else {
		doLog('fail to load accounts at '.$accounts_xml_path);
	}
	return $aResult;
}


function doLog($sMsg){
	global $aReturn;
	$aReturn['debug'][] = array('time'=>timestamp(), 'msg'=>$sMsg);
}

function timestamp(){
	return date('Y-m-d H:i:s');
}

function getRemoteIp(){
	$REMOTE_ADDR = '';
	if (isset($_SERVER['REMOTE_ADDR'])) $REMOTE_ADDR = $_SERVER['REMOTE_ADDR'];
	if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) $HTTP_X_FORWARDED_FOR = $_SERVER['HTTP_X_FORWARDED_FOR'];
	else $HTTP_X_FORWARDED_FOR = '';

	if (!empty($HTTP_X_FORWARDED_FOR)) {
		$match = array();
		if (preg_match("/^([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)/", $HTTP_X_FORWARDED_FOR, $match)) {
			$REMOTE_ADDR = preg_replace($privateIpList, $REMOTE_ADDR, $match[1]);
			#$REMOTE_ADDR = preg_replace(self::$privateIpList, $REMOTE_ADDR, $match[1]);
		}
	}

	// darwin fix
	if ($REMOTE_ADDR == '::1' || $REMOTE_ADDR == 'fe80::1') {
		$REMOTE_ADDR = '127.0.0.1';
	}

	return $REMOTE_ADDR;
}

function webauth_available(){
	if (!file_exists("/etc/systemd/system/webui-auth.service")) return 0;
	#if (!file_exists("/etc/systemd/system/multi-user.target.wants/webui-auth.service")) return 0;
	$x = shell_exec("systemctl is-active webui-auth");
	#if ($x === "active") return 1;
	$conn = new IXR_Client('http://localhost:1951/');
	$r = $conn->query('app_ver');
	if ($r) return 1;
	return 0;
}

function _update_lastacttime(){
	if (!empty($_SESSION['auth'])){
		$_SESSION['lastacttime'] = time();
	}
}

function _inactive_dur(){
	if (!empty($_SESSION['lastacttime'])){
		return time() - $_SESSION['lastacttime'];
	}
	return -1;
}


function startSession($name = 'streambox'){
	session_name($name);
	session_start();
}



function setSession($username, $password, $sessionName = 'streambox'){
	global $accounts_xml_path;
	startSession($sessionName);
	$password = md5($password);
	$isValid = false;

	if (webauth_available()){

		$conn = new IXR_Client('http://localhost:1951/');
		$r = $conn->query('auth', $username, $password, getRemoteIp());
		if (!$r){
			//echo "Error:";
			//echo $conn->getErrorCode(),":";
			//echo $conn->getErrorMessage();
			return $isValid;
		}
		$r = $conn->getResponse();
		if ($r){
			if ($r[0]==0){
				$isValid = true;
				$_SESSION['auth'] = $isValid;
				$_SESSION['username'] = $r[1][0];
				$_SESSION['name'] = $r[1][1];
				$_SESSION['type'] = $r[1][2];
				$_SESSION['bitrate'] = 0;
				$_SESSION['buffer'] = 0;
				$now = date('Y.m.d H:i:s', time());
				$_SESSION['lastaccess'] = $now;
				$_SESSION['sessionip'] = getRemoteIp();
				unset($_SESSION['lockstate']);
				unset($_SESSION['lockstate_msg']);
				unset($_SESSION['emsg']);
				$_SESSION['remaindays'] = $r[2];
				$_SESSION['lastacttime'] = time();
			} elseif ($r[0]==-4){
				$_SESSION['lockstate'] = $r[1];
				$_SESSION['lockstate_msg'] = $r[2];
				unset($_SESSION['emsg']);
			} elseif ($r[0]==-6){
				unset($_SESSION['lockstate']);
				unset($_SESSION['lockstate_msg']);
				$_SESSION['remaindays'] = -1;
				unset($_SESSION['emsg']);
			} elseif ($r[0]==-5){
				unset($_SESSION['lockstate']);
				unset($_SESSION['lockstate_msg']);
				unset($_SESSION['remaindays']);
				$_SESSION['emsg'] = $r[1];
			} else {
				unset($_SESSION['lockstate']);
				unset($_SESSION['lockstate_msg']);
				unset($_SESSION['remaindays']);
				unset($_SESSION['emsg']);
			}
		}

	} else {
		$dom = new domdocument();
		if(!$dom->load($accounts_xml_path)) {
			$dom = createXmlAccounts($accounts_xml_path);
		}
		$users = $dom->getElementsByTagName('user');
		foreach($users as $user) 	{
			if(strtolower($user->getAttribute('username')) == strtolower($username) && $user->getAttribute('pass') == $password) {
				$isValid = true;
				$_SESSION['auth'] = $isValid;
				$_SESSION['name'] = $user->getAttribute('name');
				$_SESSION['username'] = $user->getAttribute('username');
				$_SESSION['type'] = $user->getAttribute('type');
				$_SESSION['bitrate'] = 0; // just to provide initial bitrate value displayed at top (not important)
				$_SESSION['buffer'] = 0; // just to provide initial buffer value displayed at top (not important)
				$now = date('Y.m.d H:i:s', time());
				$_SESSION['lastaccess'] = $now;
				$_SESSION['sessionip'] = getRemoteIp();
				$user->setAttribute('lastaccess',$now);
				$user->setAttribute('sessionip',getRemoteIp());
				$dom->save($accounts_xml_path);
			}
		}
	}


	return $isValid;
}




?>
