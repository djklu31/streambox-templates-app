
function SendCommand(c, callback) {
	if(typeof(callback) === 'undefined'){
		callback = Update;
	}
	var url = "process.php";
	var params = "c="+encodeURIComponent(c);
	$.post(url, params, callback);
}

function SendCommandCustom(c, callback, url, onfail){
	var params = "c="+encodeURIComponent(c);
	if (onfail)
		$.post(url, params, callback).fail(onfail);
	else
		$.post(url, params, callback);
}

function NoAction(data, textStatus, xmlHttp){ }

function Show(divID)  {
    if (document.all){	//IS IE 4 or 5 (or 6 beta)
	eval("document.all." + divID + ".style.display = 'block'");
    }

    if (document.layers) { //IS NETSCAPE 4 or below
	document.layers[divID].display = "block";
    }

    if (document.getElementById) {
		var d = document.getElementById(divID);
		// disable select boxes in IE6 because they is a bug where all select boxes has top most z-index
		if($.browser.msie) {
			var x = document.getElementsByTagName("select");
			for (i = 0; i < x.length; i++) {
				x[i].style.display = "none";
			}
		}
		d.style.display = "block";
    }
}

function Hide(divID)  {
    if (document.all) {	//IS IE 4 or 5 (or 6 beta)
	eval("document.all." + divID + ".style.display = 'none'");
    }

    if (document.layers) { //IS NETSCAPE 4 or below
	document.layers[divID].display = "none";
    }

    if (document.getElementById)  {
		var d = document.getElementById(divID);
		d.style.display = "none";
		// re-enable select boxes if we disabled them before
		if($.browser.msie) {
			var x = document.getElementsByTagName("select");
			for (i = 0; i < x.length; i++) {
				x[i].style.display = "inline";
			}
		}
    }
}

function FormatTime(time)  {
	var time_array = time.split(":");
	sec = ""; min = ""; hr = "";
	if(time_array.length == 3)  {
		sec = time_array[2];
		min = time_array[1];
		hr = time_array[0];
		if(sec < 10)
			sec = "0" + sec;
		if(min < 10)
			min = "0" + min;
		if(hr < 10)
			hr = "0" + hr;
		time = hr + ":" + min + ":" + sec;
	} else if(time_array.length == 2) {
		sec = time_array[1];
		min = time_array[0];
		if(sec < 10)
			sec = "0" + sec;
		if(min < 10)
			min = "0" + min;
		time = min + ":" + sec;
	}
	return time;
}

function DisableAllFormElements()  {
	if(document.forms.length > 0) {
		objElems = document.forms[0].elements;
		for(var i=0; i<objElems.length; i++){
			objElems[i].disabled = true;
		}
	}

	objElems = document.getElementsByTagName('input');
	for(var i=0; i<objElems.length; i++){
		objElems[i].disabled = true;
	}

}

function _getParameter(pname){
	var r = null, tmp = [];
	location.search.substr(1).split("&").forEach(
		function(item){
			tmp=item.split("=");
			if (tmp[0]===pname) r=decodeURIComponent(tmp[1]);
	});
	return r;
}
function trim(str) {
	str.replace(/^\s+|\s+$/g, '');
	return str;
}
function escapeHtml(unsafe) {
    return (unsafe).toString()
         .replace(/&/g, "&amp;")
         .replace(/</g, "&lt;")
         .replace(/>/g, "&gt;")
         .replace(/"/g, "&quot;")
         .replace(/'/g, "&#039;");
}

