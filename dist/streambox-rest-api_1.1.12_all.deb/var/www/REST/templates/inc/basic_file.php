<?php




class BasicFileMan {

	var $docRoot = "/var/lib/avenir/WebData/templates";
	//var $fbcl="\r\n\t\"'&;:/\\*?<>|%" ;
	var $fbcl="/\r|\n|\t|\"|'|&|;|:|\\/|\\||\\*|\\?|<|>|\\\\|#|%/" ;

	var $k_candidates = array(
			"/var/www/WebData", "/var/local/WebData", "/var/lib/avenir/WebData"
		);

	var $skip_file_list = array("..", ".");


	function __construct(){
		$this->set_doc_root();
	}

	function set_doc_root(){
		$k = null;
		foreach($this->k_candidates as $i){
			if (is_dir($i)){
				$k = $i;
				break;
			}
		}
		if ($k) $this->docRoot = $k;
	}

	function has_illigal_char($s){
		$r = preg_match($this->fbcl, $s);
		return $r;
	}

	function encode_and_return_json($s){
		global $JSON_ENC_OPT ;
		echo json_encode($s, $JSON_ENC_OPT);
		exit;
	}

	function return_err_as_json($s, $errID=1){
		global $JSON_ENC_OPT ;
		$r = array();
		$r['err'] = $errID;
		$r['errmsg'] = $s;
		echo json_encode($r, $JSON_ENC_OPT);
		exit;
	}

	function handleHTTPRequest($_URL){
		global $JSON_ENC_OPT ;
		global $http_method;
		//$http_method = $_SERVER['REQUEST_METHOD'];

		if (
			(!$_URL && $http_method=="GET")
			|| ($_URL=="_list" && $http_method=="GET")
		){
			header('Content-Type: application/json');
			return $this->encode_and_return_json($this->getFileNames());
		}



		if (($http_method=="GET") && $_URL){

			$fname = $_URL;
			$fullpath = $this->docRoot . DIRECTORY_SEPARATOR . $fname;
			if (!file_exists($fullpath)){
				header('Content-Type: application/json');
				$this->return_err_as_json("file not exists", 1);
			}

			if( preg_match("/.*\\.json/i", $fname)){
				header('Content-Type: application/json');
			} else {
				if (0)
					header('Content-Type: application/octet-stream');
				elseif (0)
					header('Content-Type: text/plain');
			}
			echo file_get_contents($fullpath);
			exit;

		}




		header('Content-Type: application/json');

		switch($http_method){
		  case "DELETE":
			$upl = explode("/", $_URL);
			if (! count( $upl )){
				return $this->return_err_as_json("invalid filename",2);
			}
			$fname= $upl[count($upl)-1];
			if ($this->has_illigal_char($fname)){
				return $this->return_err_as_json("invalid filename",2);
			}

			$fullpath = $this->docRoot . DIRECTORY_SEPARATOR . $fname;
			if (!file_exists($fullpath)){
				return $this->return_err_as_json("file not exists", 1);
			}

			$r = unlink($fullpath);
			if (!$r){
				return $this->return_err_as_json("failed to delete", 9);
			}

			return $this->return_err_as_json("deleted", 0);

			break;

		  //case "GET":
		  case "POST":
			if (!isset($_REQUEST["filename"]) || !isset($_REQUEST["filedata"])  ) 
				$this->return_err_as_json("nodata?", 3);
			if (!($_REQUEST["filename"]) || !($_REQUEST["filedata"])  )
				$this->return_err_as_json("nodata?", 4);
			// switch($_REQUEST["cmd"]){ }
			$fname = $_REQUEST["filename"];
			$fdata = $_REQUEST["filedata"];
			if ($this->has_illigal_char($fname)){
				return $this->return_err_as_json("invalid filename",2);
			}

			$fullpath = $this->docRoot . DIRECTORY_SEPARATOR . $fname;
			$f = fopen($fullpath, "w");
			if (!$f){
				return $this->return_err_as_json("failed to open file " . $fullpath, 6);
			}
			fwrite($f, $fdata);
			fclose($f);
			$this->return_err_as_json("written", 0);

			break;
		}

		$this->return_err_as_json("invalid access?", 5);
	}


	function getFileNames(){
		$r = array();
		$dirh = opendir($this->docRoot);
		if (!$dirh){
			return $r;
		}
		
		while (($s = readdir($dirh))!==false){
			if (in_array($s, $this->skip_file_list)) continue;
			// printf("filename: \"%s\"\n", $s);
			$fullpath = $this->docRoot . DIRECTORY_SEPARATOR . $s;
			if (!is_file($fullpath)) continue;

			$st = @stat($fullpath);
			if (! $st) continue;

			$r[] = array(
				"name"=> $s
				,"size"=> $st[7]
				,"uid" => $st[4]
				,"gid" => $st[5]
				,"mtime"=>$st[9]
				,"mode"=> $st[2]
				,"modet"=> sprintf("%o", $st[2])
			);
		}
		closedir($dirh);
		sort($r,  SORT_NATURAL);
		return $r;

	}


};


class TmplFileMan extends BasicFileMan {

	function __construct(){
		$this->k_candidates = array(
			 "/var/www/WebData/templates"
			,"/var/local/WebData/templates"
			,"/var/lib/avenir/WebData/templates"
		);
		parent::__construct();
		//$this->set_doc_root();
	}

};



//$bfm = new BasicFileMan();
if (0){
	$bfm = new TmplFileMan();
	print_r($bfm->getFileNames());


	$fbcl="\r\n\t\"'&;:/\\*?<>|#" ;
	$fbcl .= "ABC DFG";
	for($i=0; $i<strlen($fbcl); $i++){
		$s = "test(" . $fbcl[$i] .")";
		printf("match:\"%s\": %d\n", $s, $bfm->has_illigal_char($s) );
	}

}


?>
