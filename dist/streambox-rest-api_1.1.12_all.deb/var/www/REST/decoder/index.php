<?php
if (file_exists("auth.inc"))
	include_once("auth.inc"); // could do authentication before sending header..


$ENC_HOST="localhost";
$ENC_PORT=1801;
$JSON_ENC_OPT = JSON_PRETTY_PRINT;
//$JSON_ENC_OPT = 0; //remove white space for compactness
include_once("../sys/inc/phpsock.inc");

if (!isset($_REQUEST["_url"])) $_REQUEST["_url"] = "";

if ($_REQUEST["_url"]=="api-ver"){
	echo file_get_contents("../version.txt");
	exit;
}

$_URL = $_REQUEST["_url"];
$upl = explode("/", $_URL);
if (count($upl)>0 && preg_match("/^(\\d+)$/", $upl[0],$m)){
	unset($upl[0]);
	$upl = array_values($upl); // renumber
	$_p = intval($m[1]);
	if ($_p>1800 && $_p<1840) $ENC_PORT = $_p;
}
$_URL = implode("/", $upl);


if (strpos(strval($_URL),"preview/BMP")===0){
	header('Content-Type: image/bmp');
	$encpt = new CSendObject($ENC_HOST, $ENC_PORT);
	echo $encpt->sendCommand2("getbmp");
	exit;
}
if (strpos(strval($_URL),"preview/JPG")===0){
	header('Content-Type: image/jpeg');
	$encpt = new CSendObject($ENC_HOST, $ENC_PORT);
	echo $encpt->sendCommand2("getjpg");
	exit;
}

header('Content-Type: application/json');

include_once("../sys/inc/phpsock.inc");
include_once("inc/preset_field.php");
include_once("inc/xml_pf.php");

//// print_r(getallheaders()); ////
// could check getallheaders(); for auth...



$pfman = new PFMan();
$encpt = new CSendObject($ENC_HOST, $ENC_PORT);

if (isset($upl[0]) && $upl[0]=="presets"){
	$pxman = new PresetXMLMan();
	$pxman->handleHTTPRequest($_URL, $encpt);
	exit;
}

if (isset($upl[0]) && $upl[0]=="features"){
	include_once("inc/feat.php");
	$fman = new FeatMan();
	$fman->handleHTTPRequest($_URL, $encpt);
	exit;
}

if (isset($_POST['c']) && $_POST['c']){
	$c = json_decode($_POST['c'], true);
	if (isset($c["action_list"])){
		$n = $pfman->action($encpt, $c["action_list"]);
		echo json_encode(["result_code"=>$n, "message"=>"Done"], $JSON_ENC_OPT);
		exit;
	}
	$val_list = $c["val_list"];
	if ($val_list){
		$n = $pfman->setAll($encpt, $val_list);
		//if ($n){}
		echo json_encode(["result_code"=>$n, "message"=>"Done"], $JSON_ENC_OPT);
		exit;
	}
	exit;
}


$pf_profs = $pfman->getCmdList_url($_URL);
$rdata = [ "current_stat" => $pfman->fetchResults($encpt, $pf_profs) ];
echo json_encode($rdata, $JSON_ENC_OPT);




?>
