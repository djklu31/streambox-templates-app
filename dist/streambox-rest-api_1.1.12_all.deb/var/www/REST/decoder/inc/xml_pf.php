<?php

include_once("../../sys/inc/phpsock.inc");
include_once("preset_field.php");


// $ps_illigal_chars = "\r\n\t\"'&;:/\\*?<>|" ;
function _ps_isvalid($s){
	return ! preg_match("/[\r\n\t\"'&;:\\/\\\\*?<>|]/", $s) ;
}


$cname_xmltag_dict = array(
	"TargetBitrate" => "TargetBitrate" 
	,"VBR" => "VBR" 
	,"FEC" => "FEC" 

	,"Resolution" => "Resolution" 
	,"FrameRate" => "FrameRate" 
	,"KeyFrame" => "KeyFrame" 

	,"BitDepth" => "BitDepth" 
	,"ColorSpace" => "ColorSpace" 
	,"NativeColorSpace" => "NativeColorSpace" 
	//"VideoBits"

	,"PreferQuality" => "PreferQuality" 
	,"PreferQualityI" => "PreferQualityI" 
	,"PreferQualityP" => "PreferQualityP" 

	,"RecycleIntra" => "RecycleIntra" 
	,"Deinterlace" => "Deinterlace" 
	,"ODCT" => "ODCT" 
	,"SoftFilter" => "SoftFilter" 
	,"MinmaxFilter" => "MinmaxFilter" 

	,"DynamicStatus" => "DynamicStatus" 
	,"DynamicRes" => "DynamicRes" 

	,"AudioCodec" => "AudioCodec" 
	,"AudioChannels" => "AudioChannels" 
	,"SampleRate" => "SampleRate" 

	,"ldmp-use" =>      "ldmp-use" 
	,"ldmp-manual" =>   "ldmp-on" 
	,"ldmp-cwnd" =>     "ldmp-cwnd" 
	,"ldmp-cwndmin" =>  "ldmp-cwndmin" 
	,"ldmp-cwndmax" =>  "ldmp-cwndmax" 
	,"ldmp-ackto" =>    "ldmp-ackto" 
	,"ldmp-sndto" =>    "ldmp-sndto" 
	,"ldmp-rttm" =>     "ldmp-rttm" 
	,"ldmp-jitter2p" => "ldmp-jitter2p" 
	,"ldmp-maxbrt" =>   "ldmp-maxbrt" 

	,"Meta_Network1" => "Meta_Network1" 
	,"Meta_Slug"     => "Meta_Slug" 
	,"Meta_Location" => "Meta_Location" 
	,"Meta_Reporter" => "Meta_Reporter" 
	,"Meta_Producer" => "Meta_Producer" 

	,"multiplex" => "multiplex"  // UDP mode

	,"AudioInput" => "audio_input" 
	,"VideoInput" => "video_source" 

/******
	,"decoderIP" => "decoderIP" 
	,"port" => "port" 
	,"ttl" => "ttl" 
	,"packetsize" => "packetsize" 
	,"stuffing" => "stuffing" 
	,"shuffle" => "shuffle" 

	,"PreviewOverlay" => "PreviewOverlay" 
	,"Force3D" => "Force3D" 

	,"crypt_mode" => "crypt_mode" 
	,"crypt_key" => "crypt_key" 

	,"" => "" 
	,"" => "" 
*******/

);

$xmltag_cname_dict = array();
foreach ($cname_xmltag_dict as $k => $v){
	$xmltag_cname_dict[$v] = $k;
}



class PresetXMLField {
	var $xmltagname;
	var $pf;
	var $d;

	function __construct($xmltag, $pf){
		$this->xmltagname = $xmltag;
		$this->pf = $pf;
		//$this->d  = $v;
	}

}


class PresetXML {
	var $pname;
	var $fds = [];

	function __construct($pn){
		$this->pname    = $pn;
	}

	function add_field($pf, $xmltag, $v=null){
		$xpf = new PresetXMLField($xmltag, $pf);
		if (!is_null($v)) $xpf->d = $v;
		$this->fds[] = $xpf;
	}

	function remake_by_pfcat($encpt, $cat){
		global $cname_xmltag_dict ;
		$catID = 0;
		$this->fds = [];
		if ($cat & 1) $catID += 1;
		if ($cat & 2) $catID += (2 + 16);
		if ($cat & 8) $catID += 8;
		$pfman = new PFMan();
		$pflist = $pfman->getPFList($catID);
		// print_r($pflist);
		foreach($pflist as $pf){
			if (!isset($cname_xmltag_dict[$pf->cname])) continue;
			$xmltag = $cname_xmltag_dict[$pf->cname];
			$v = $encpt->sendCommand($pf->getCmd())["result"];
			$v = $pf->parse($v);
			$this->add_field($pf, $xmltag, $v);
		}
	}
}

// if (php_uname('s')=="Linux")
$pf_xml = "/var/lib/avenir/conf/userpresets.xml";

class PresetXMLMan {
	var $pss = [];
	var $fname = "";
	var $encpt = null;

	function __construct($fname="--AUTO--"){
		global $pf_xml;
		if (is_null($fname)) return;
		if ($fname==="--AUTO--"){
			if (php_uname('s')=="Linux") $fname = $pf_xml;
		}
		$this->load_file($fname);
	}

	function load_file($fname){
		global $pf_base_set;
		global $cname_xmltag_dict ;
		global $xmltag_cname_dict ;
		$this->fname = $fname;
		$d = simplexml_load_file($fname);

		if ($d===false)
			$d = simplexml_load_string("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<Presets platform=\"linux\">\n</Presets>");

		$k = new SimpleXmlIterator($d->asXML());
		for($k->rewind(); $k->valid(); $k->next()){
			if ($k->key()!=="Preset"){
				// non-preset element
				continue;
			}
			$xp = new PresetXML("--");
			//print_r($k->current());
			$l = $k->current();
			for($l->rewind(); $l->valid(); $l->next()){
				//printf("%22s : %s\n", $l->key(), $l->current());
				$elename = strval($l->key());
				$eleval  = strval($l->current());
				if ($elename==="Name") $xp->pname = $eleval;
				else {
					$elename = $this->_adjust_xmltag($elename);
					if (!array_key_exists($elename, $xmltag_cname_dict)) continue;
					$cname = $xmltag_cname_dict[$elename];
					$pf = 0;
					foreach($pf_base_set as $_pf){
						if ($_pf->cname == $cname){
							$pf = $_pf;
							break;
						}
					}
					if ($pf){
						$xp->add_field($pf, $elename, $eleval);
						//printf(" added: %22s : %s\n", $l->key(), $l->current());
					}
				}
			}
			if (count($xp->fds)>0) $this->pss[] = $xp;
		}
	}

	function applypreset($pid){
		$pr = $this->pss[$pid];
		$fds = $pr->fds;
		$r = array();
		foreach($fds as $xpf){
			$cmds = $xpf->pf->setCmds($xpf->d);
			foreach($cmds as $cmd){
				$r[] = $cmd;
			}
		}
		foreach($r as $cmd) $this->encpt->sendCommand($cmd);

		$this->output_error_json(1, $r);
	}

	function save_list(){
		### save as is
                $R = simplexml_load_string("<?xml version=\"1.0\" encoding=\"UTF-8\" ?>\n<Presets platform=\"linux\">\n</Presets>");
		foreach($this->pss as $xp){
			$p = $R->addChild("Preset");
			$p->addChild("Name", $xp->pname);
			foreach($xp->fds as $xpf){
				$p->addChild($xpf->xmltagname, $xpf->d);
			}
		}
		//echo $R->asXML();
		//return;
		if (1){
			### save with pretty format
			$dom = new domdocument("1.0","UTF-8");
			$dom->preserveWhiteSpace = false;
			$dom->formatOutput = true;
			$dom->loadXML($R->asXML());
			//print $dom->saveXML();
			$dom->save($this->fname);
			chmod($this->fname, 0666);
		}
	}

	function _adjust_xmltag($s){
		if ($s==="VideoBits") return "BitDepth";
		return $s;
	}

	function dp(){
		foreach ($this->pss as $xp){
			echo "preset:", $xp->pname, "\n";
			foreach($xp->fds as $xpf){
				printf("%22s : %s\n", $xpf->pf->cname, $xpf->d);
			}
			print "\n";
		}
	}

	function get_pf_list(){
		$r = array();
		$i = 0;
		foreach($this->pss as $xp){
			$r[] = array("pid"=> $i, "pname"=> $xp->pname);
			$i++;
		}
		return array( "preset_list" => $r);
	}
	function output_error_json($n, $msg, $e=1){
		global $JSON_ENC_OPT ;
		//$JSON_ENC_OPT = JSON_PRETTY_PRINT;
		echo json_encode(["result_code"=>$n, "message"=>$msg], $JSON_ENC_OPT);
		if ($e) exit;
	}

	function handleHTTPRequest($_URL, $encpt){
		global $JSON_ENC_OPT ;
		$this->encpt = $encpt;
		$n = 0;
		if (isset($_POST['c']) && $_POST['c']){
			$c = json_decode($_POST['c'], true);
			if (!isset($c["command"])){
				$this->output_error_json(-1, "invalid command");
				return;
			}
			$cmd = $c["command"];
			switch($cmd){
			  case "apply":
				$pid = $c["pid"];
				$l = count($this->pss);
				if ($pid<0 || $pid>=$l) $this->output_error_json(-2, "out of range: ". $pid);
				$this->applypreset($pid);
				break;
			  case "remove":
				$pid = $c["pid"];
				$l = count($this->pss);
				if ($pid<0 || $pid>=$l) $this->output_error_json(-2, "out of range: ". $pid);
				unset($this->pss[$pid]);
				$this->pss = array_values($this->pss);
				$this->save_list();
				$this->output_error_json(0, "#presets: ". count($this->pss));
				break;
			  case "overwrite":
				$pid = $c["pid"];
				$cat = $c["cat"];
				$l = count($this->pss);
				if ($pid<0 || $pid>=$l) $this->output_error_json(-2, "out of range: ". $pid);
				$this->pss[$pid]->remake_by_pfcat($encpt, $cat);
				$this->save_list();
				$this->output_error_json(0, "#presets: ". count($this->pss));
				break;
			  case "save_new":
				$cat = $c["cat"];
				$pname = $c["pname"];
				$pname = trim($pname);
				if (!$pname) $this->output_error_json(-3, "no preset name");
				if (!_ps_isvalid($pname)) $this->output_error_json(-4, "invalid preset name");
				$px = new PresetXML($pname);
				$px->remake_by_pfcat($encpt, $cat);
				$this->pss[] = $px;
				$this->save_list();
				$this->output_error_json(0, "#presets: ". count($this->pss));
				break;
			}
			//$n = $pfman->action($encpt, $c["action_list"]);
			//echo json_encode(["result_code"=>$n, "message"=>"Done"], $JSON_ENC_OPT);
			echo json_encode(["result_code"=>0, "message"=>"Done"], $JSON_ENC_OPT);
			exit;
		}
		echo json_encode($this->get_pf_list(), $JSON_ENC_OPT);
	}

};


function _is_cli()
{
	if( defined('STDIN') ){
		return true;
	}
	if( empty($_SERVER['REMOTE_ADDR']) and !isset($_SERVER['HTTP_USER_AGENT']) and count($_SERVER['argv']) > 0){
		return true;
	} 
	return false;
}


if(php_sapi_name()==="cli"){
	$JSON_ENC_OPT = JSON_PRETTY_PRINT;
	$ENC_HOST="localhost";
	$ENC_PORT=1801;
	$encpt = new CSendObject($ENC_HOST, $ENC_PORT);

	$pm = new PresetXMLMan();;
	$pm->dp();
	echo json_encode($pm->get_pf_list(), JSON_PRETTY_PRINT), "\n";
	echo "s (os)  : ", php_uname('s'), "\n";;
	echo "n (host): ", php_uname('n'), "\n";;
	echo "r (rele): ", php_uname('r'), "\n";;
	echo "v (ver ): ", php_uname('v'), "\n";;
	echo "m (mach): ", php_uname('m'), "\n";;
	//$pm->save_list();
	echo count($pm->pss);
	$pm->pss[ count($pm->pss)-1 ]->remake_by_pfcat($encpt, 2);
	//$pm->dp();
	if (0){
		$s = "test&test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test-test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "testatest"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test/test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test\ttest"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test\\atest"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test\natest"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test\ratest"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test;test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test*test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test?test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test<test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "test>test"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = "/"; printf(" %20s -> %d\n",$s, ps_isvalid($s));
		$s = " "; printf(" %20s -> %d\n",$s, ps_isvalid($s));
	}
}
?>
