<?php

include_once("../../sys/inc/IXR_Library.inc");
include_once("inc/decipidtable.php");

define("_PF_TYPE_STR"      , 0);
define("_PF_TYPE_INT"      , 1);
define("_PF_TYPE_SUB_INT"  , 2);
define("_PF_TYPE_ZERO_ONE" , 3);
define("_PF_TYPE_ON_OFF  " , 4); // no longer used
define("_PF_TYPE_INT_RANGE", 5);
define("_PF_TYPE_CUSTOM"   , 6);

define("_PF_ERR_OBJ", null);


function GET_PF_TYPE_NAME($v){
	switch($v){
	  case 0: return "PF_TYPE_STR";
	  case 1: return "PF_TYPE_INT";
	  case 2: return "PF_TYPE_SUB_INT";
	  case 3: return "PF_TYPE_ZERO_ONE";
	  case 4: return "PF_TYPE_ON_OFF";
	  case 5: return "PF_TYPE_INT_RANGE";
	  case 6: return "PF_TYPE_CUSTOM";
	  default:return "PF_TYPE_STR";
	}
}



class PresetField {
	var $pftype;
	var $cname;
	var $label;
	var $cmd_base;
	var $default_value;
	var $desc = "";
	var $value_type;
	var $_custom_getcmd_ = null;
	var $_should_trim = 1;
	var $_unsupported_result_ok_ = 0;
	var $_isHD = 1;
	var $_ret_on_err = 0;
	var $v;
	var $_err = 0;
	var $_need_restart = 0;
	var $_read_only = 0;
	var $_cname_is_getcmd = 0;
	var $_skip_in_preset = 0;

	var $_set_cmd_  = null;
	var $_set_cmds_ = null;
	var $_set_ex_cmd_  = null;
	var $_get_ex_cmd_  = null;
	var $val_set = [];
	var $label_list = array();

	function __construct($cn, $l, $cmd, $dv){
		$this->pftype   = _PF_TYPE_STR;
		$this->cname    = $cn;
		$this->label    = $l;
		$this->cmd_base = $cmd;
		$this->default_value = $dv;
		$this->v             = $dv;
	}

	function getCmd(){
		if ($this->_custom_getcmd_) return $this->_custom_getcmd_;
		if ($this->_cname_is_getcmd) return $this->cname;
		return "get::" . $this->cmd_base ;
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		return "set::" . $this->cmd_base . "::" . ($v) ;
	}

	function setCmds($v){
		if ($this->_set_cmds_) return ($this->_set_cmds_)($v);
		$r = [];
		$s = $this->setCmd($v);
		if ($s) $r[] = $s;
		return $r;
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		$this->v = $s;
		return $s;
	}

	function _parse_int($s, $on_err=0){
		$v = intval($s);
		$this->v = $v;
		return $v;
	}

	function getLabelList(){
		return $this->label_list;
	}

	function setLabelList($l){
		$this->label_list = $l;
	}

	function return_on_err($on_err=0){
		$e = $on_err;
		if ($on_err==0) $e = $this->_ret_on_err;
		switch ($e){
		  case 0:
			return $this->default_value;
		  case 1:
			return _PF_ERR_OBJ;
		  default:
			return $this->default_value;
		}
	}

	function _is_in_range($v){
		return 1;
	}

	function __destruct() {
		//parent::__destruct();
	}


};

class PresetField_STR extends PresetField {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
	}
}

class PresetField_STR_RO extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->_read_only = 1;
	}
}

class PresetField_CUSTOM extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_CUSTOM;
	}
}

class PresetField_CUSTOM_RO extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_CUSTOM;
		$this->_read_only = 1;
	}
}

class PresetField_INT extends PresetField {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_INT;
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		$v = $this->_parse_int($s);
		if (! $this->_is_in_range($v)){
			$this->_err = 2;
			$this->v = $this->return_on_err();
			return $this->return_on_err();
		}
		return $v;
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if (! $this->_is_in_range($v)){
			return "";
		}
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		return "set::" . $this->cmd_base . "::" . strval($v) ;
	}
};


class PresetField_INT_RO extends PresetField_INT {
	function __construct($cn, $l, $cmd, $dv, $cname_is_cmd=0){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_INT;
		$this->_read_only = 1;
		$this->_cname_is_getcmd = $cname_is_cmd;
	}
}


class PresetField_INT_RANGE extends PresetField_INT {
	var $low;
	var $high;
	function __construct($cn, $l, $cmd, $dv, $low, $high){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_INT_RANGE;
		$this->low  = $low;
		$this->high = $high;
		//$this->setLabelList($lv);
	}

	function _is_in_range($v){
		if ($v>=$this->low && $v<=$this->high) return 1;
		return 0;
	}

};


class PresetField_SUB_INT extends PresetField_INT {
	function __construct($cn, $l, $cmd, $dv, $subset, $lv){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->pftype = _PF_TYPE_SUB_INT;
		$this->val_set = $subset;
		$this->setLabelList($lv);
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		$v = $this->_parse_int($s);
		if (! in_array($v, $this->val_set)){
			$this->_err = 2;
			$this->v = $this->return_on_err();
			//$this->v = $this->default_value;
			return $this->return_on_err();
		}
		return $v;
	}

	function _is_in_range($v){
		if (in_array($v, $this->val_set)) return 1;
		return 0;
	}

};


class PresetField_ZERO_ONE extends PresetField_SUB_INT {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv, [0,1], Array());
		$this->pftype = _PF_TYPE_ZERO_ONE;
	}
};


// basically boolean but accessor use ON/OFF, (cf. use get::***=>"OFF", set::***::OFF)
class PresetField_ON_OFF extends PresetField_ZERO_ONE {
	function __construct($cn, $l, $cmd, $dv){
		parent::__construct($cn, $l, $cmd, $dv, [0,1], Array());
		$this->pftype = _PF_TYPE_ZERO_ONE;
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		if ( strcasecmp($s, "ON")==0) return 1;
		if ( strcasecmp($s, "OFF")==0) return 0;
		return $this->return_on_err();
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if (! $this->_is_in_range($v)){
			return "";
		}
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		switch ($v){
		  case 0:
			return "set::" . $this->cmd_base . "::" . "OFF" ;
			break;
		  case 1:
			return "set::" . $this->cmd_base . "::" . "ON" ;
			break;
		}
		return "";
	}

};


class PresetField_IP_MODE extends PresetField_SUB_INT {
	function __construct($cn, $l, $cmd, $dv, $subset, $lv){
		parent::__construct($cn, $l, $cmd, $dv, $subset, $lv);
	}

	function parse($s, $on_err=0){
		$this->_err = 0;
		if ( strcasecmp($s, "IP")==0) return 0;
		if ( strcasecmp($s, "IP M-CAST")==0) return 1;
		return $this->return_on_err();
	}

	function setCmd($v){
		if ($this->_read_only) return "";
		if (! $this->_is_in_range($v)){
			return "";
		}
		if ($this->_set_cmd_) return ($this->_set_cmd_)($v);
		switch ($v){
		  case 0:
			return "set::action::1005";
			break;
		  case 1:
			return "set::action::1006";
			break;
		}
		return "";
	}

};


class PresetField_JITTER extends PresetField_SUB_INT {
	function __construct($cn, $l, $cmd, $dv, $subset, $lv){
		parent::__construct($cn, $l, $cmd, $dv, $subset, $lv);
	}
	function parse($s, $on_err=0){
		$j = [ 0,5,10,30,50,100,300,500,800,1000,2000 ];
		$v = $this->_parse_int($s);
		for ($i=0; $i<count($j); $i++){
			if ($j[$i]==$v) return $i;
		}
		$this->_err = 2;
		$this->v = $this->return_on_err();
		return $this->return_on_err();
	}

	function setCmd($v){
		$j = [ 0,5,10,30,50,100,300,500,800,1000,2000 ];
		if (($v<0) || (count($j)<=$v)) return "";
		return "set::" . $this->cmd_base . "::" . ($j[$v]);
	}

}

$inf_dec_ip = new PresetField("decoder_ip", "Decoder IP", "INFO::IP", "N/A");
$inf_bitrate = new PresetField("bitrate", "Bitrate", "INFO::BITRATE", "N/A");
$inf_lost_packets = new PresetField_INT("lost_packets", "Lost Frames", "INFO::LOST", 0);
$inf_recov_frames = new PresetField_INT("recov_frames", "Recovered Packets", "INFO::RECOV", 0);

$inf_dec_vid = new PresetField_STR_RO("inf_dec_vid","Video(FPS)","INFO::STANDARD","N/A");

$inf_dec_nif  = new PresetField_INT_RANGE("inf_dec_nif" , "Num I/Fs", "stats_num_int" , 0, 0, 127);


$inf_cjitter  = new PresetField_INT("cjitter", "Jitter", "INFO::JITTER", 0);
$inf_cjitter2 = new PresetField_INT("cjitter2", "Jitter2", "INFO::JITTER2", 0);
$inf_field_order = new PresetField("field_order", "Field Order", "OUTPUT::FIELDS", "N/A");
$inf_codec_ver     = new PresetField("codec_ver", "Codec Type/Version", "codec_version", "N/A");

$inf_crypt_state   = new PresetField_SUB_INT("crypt_state", "Encryption State", "EncryptionState", 0, [0,1,2,3,4], ["OFF","AES-128","AES-192","AES-256","Ghost15"]);
$inf_crypt_warn    = new PresetField_ZERO_ONE("crypt_warn", "Encryption Warning", "EncryptionWarn", 0);
$inf_codec_error   = new PresetField_ZERO_ONE("codec_error", "Codec Error", "codec_error", 0);
$inf_feature_error = new PresetField_ZERO_ONE("feature_error", "Feature Error", "FeatureError", 0);

$inf_meta_title    = new PresetField("meta_title", "Title", "INFO::METADATA::SLUG", "");
$inf_meta_location = new PresetField("meta_location", "Location", "INFO::METADATA::LOCATION", "");
$inf_meta_reporter = new PresetField("meta_reporter", "Reporter", "INFO::METADATA::REPORTER", "");
//$inf_meta_ = new PresetField("meta_producer", "Producer", "INFO::METADATA::PRODUCER", "");

$inf_video = new PresetField("video", "Video", "INFO::VIDEO", "N/A");
$inf_audio = new PresetField("audio", "Audio", "INFO::AUDIO", "N/A");
$inf_color_prof = new PresetField("color_prof", "Color Profile", "INFO::PROFILE", "N/A");
$inf_fec = new PresetField("fec", "FEC", "INFO::FEC", "N/A");
$inf_ishuffle = new PresetField("ishuffle", "Shuffle", "INFO::SHUFFLE", "N/A");

$inf_ = new PresetField("", "", "", "N/A");
$inf_ = new PresetField("", "", "", "N/A");
$inf_ = new PresetField_INT("", "", "", 0);
$inf_ = new PresetField_INT("", "", "", 0);

$inf_dolby_vision  = new PresetField_SUB_INT("dolby_vision", "Dolby Vision", "DolbyTunneling", 0, [0,1,2], ["OFF","HDMI","CMU"]);


$pf_auto_jitter = new PresetField_ON_OFF("auto_jitter", "Auto Jitter", "network::autojitter", 0);



$inf_insignal = new PresetField("inputsignal", "Signal", "inputsignal", "N/A");
$inf_netmode = new PresetField("cnetworkmode", "Net Mode", "networkmode", "N/A");
$inf_cur_bitrate = new PresetField("cur_bitrate", "Bitrate", "INFO::C-BITRATE", "N/A");
$inf_isstream  = new PresetField_ZERO_ONE("isStreaming", "Is streaming?", "isStreaming", 0);
$inf_isrecord  = new PresetField_ZERO_ONE("isRecording", "Is recording?", "isRecording", 0);
$inf_isrestart = new PresetField_ZERO_ONE("isRestarting", "Is restarting?", "isrestarting", 0);
$inf_abnstatus = new PresetField_INT("abn_status", "ABN Status", "abn_status", 0); $inf_abnstatus->_custom_getcmd_ ="abn_status";
$inf_sdi_error = new PresetField_INT("sdi_error", "SDI Error", "sdi_error", 0);    $inf_sdi_error->_custom_getcmd_ ="sdi_error";
$inf_dropcapt = new PresetField_INT("dropCapture", "Dropped Capture Frames", "INFO::DROP-CAP", "N/A");
$inf_dropenc = new PresetField_INT("dropEnc", "Dropped Encoder Frames", "INFO::DROP-ENC", 0);
$inf_quality = new PresetField("vquality", "Quality", "INFO::QUALITY", "");
$inf_framedelay = new PresetField_INT("frame_delay", "Frame Delay", "INFO::FRAME-DELAY", 0);
$inf_shuffle = new PresetField_INT("cshuffle", "Shuffle", "INFO::SHUFFLE", 0);
$inf_buffer  = new PresetField("cbuffer", "Buffer", "INFO::BUFFER", "");
$inf_bytes   = new PresetField("cbytes", "Bytes", "INFO::BYTES","");
$inf_sentpacket = new PresetField_INT("sent_packets", "Packets Sent", "INFO::PACKETS", 0);

$inf_captDolbyRaw = new PresetField_INT("captureDolbyRaw", "Capture Dolby Raw", "CaptureDolbyRaw", 0);
$inf_dolbyInfoPre = new PresetField_INT("dolbyInfoPresent", "Dolby Info?", "DolbyInfo_Present", 0);
$inf_pkt_size = new PresetField_INT("c_packetsize", "Packets Size", "packetsize", 0);
$inf_is_ldmp = new PresetField_ZERO_ONE("is_ldmp", "Is LDMP?", "UseMPUDP", 0);

$inf_decoder_ip1 = new PresetField("c_decoderIP", "Decoder IP", "INFO::D0", "N/A");
$inf_decoder_ip2 = new PresetField("c_decoderIP2", "Decoder IP(2)", "INFO::D1", "N/A");
$inf_encoder_ip1 = new PresetField("c_encoderIP", "Encoder IP", "INFO::N0", "");
$inf_encoder_ip2 = new PresetField("c_encoderIP2", "Encoder IP(2)", "INFO::N1", "");

$inf_enc_ver   = new PresetField_STR_RO("version", "Encoder Version","INFO::VERSION","N/A");
$inf_builddate = new PresetField_STR_RO("build_date", "Encoder Build Date","INFO::BD","N/A");



$pf_meta_tit  = new PresetField("Meta_Slug", "Title", "Meta_Slug", "");
$pf_meta_rep  = new PresetField("Meta_Reporter", "Reporter", "Meta_Reporter", "");
$pf_meta_loc  = new PresetField("Meta_Location", "Location", "Meta_Location", "");
$pf_meta_pro  = new PresetField("Meta_Producer", "Producer", "Meta_Producer", "");
$pf_meta_drm  = new PresetField("Meta_Network1", "DRM/Session", "Meta_Network1", "");

$pf_bitrate    = new PresetField_INT("TargetBitrate", "Target Bitrate", "bitrate", 2000*1000);
$pf_framerate  = new PresetField_SUB_INT("FrameRate", "Framerate", "framerate", 0, [0,1,2,3,4,5],["Full","3/4","1/2","1/3","1/4","1/5"]);
$pf_keyframe   = new PresetField_INT("KeyFrame", "Key frame", "iframe", 30 );
$pf_vbr        = new PresetField("VBR", "VBR Buffer", "vbr", "0.5");
$pf_colorProf  = new PresetField_SUB_INT("ColorSpace", "Color Profile", "color", 1, [0,1,2], ["4:2:0","4:2:2","4:4:4"]);
$pf_colorSpace = new PresetField_SUB_INT("NativeColorSpace", "Color Space", "nativecolorspace", 0, [0,1,2,3,65535]
	, ["DCI/ICT RGB","Native RGB","NativeXYZ","Rec. 709 Full","Default"]);
$pf_bitdepth  = new PresetField_SUB_INT("BitDepth", "Color Bit Depth", "video-bits", 8, [8,10,12],["8","10","12"]);

$fecLabelList = ["OFF", "1%,100p", "2%,50p", "2.5%,40p", "5%,20p", "10%,10p", "12.5%,8p", "16%,6p", "20%,5p", "25%,4p", "33%,3p", "50%,2p", "3% RS-64/2", "6% RS-32/2", "8% RS-24/2", "11% RS-16/2", "20% RS-8/2", "25% RS-6/2", "33% RS-4/2", "7% RS-64/5", "10% RS-48/5", "14% RS-32/5", "38% RS-8/5", "45% RS-6/5", "14% RS-64/10", "18% RS-48/10", "23% RS-32/10", "38% RS-16/10", "34% RS-64/32", "40% RS-48/32", "42% RS-64/48"];

$pf_fec = new PresetField_SUB_INT("FEC", "FEC", "fec", 0 
	,[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30]
	,$fecLabelList
);


$pf_reso       = new PresetField_SUB_INT("Resolution" , "Resolution", "resolution" , 0, [0,1,2,3,4,5,6],["FULL", "3/4","2/3","1/2","CIF","QVGA","Single Field"]);


$inf_audiolevel  = new PresetField_INT_RO("audiolevel", "Audio Level", "audiolevel", "");
//$inf_audiolevels = new PresetField_CUSTOM_RO("audiolevels", "Audio Levels", "audiolevels", "");
$inf_audiolevels = new PresetField_STR_RO("audiolevels", "Audio Levels", "audiolevels", "");



$pf_audio_codec   = new PresetField_SUB_INT("AudioCodec", "Audio Codec", "audiocodec", 0,[0,1,2,3,4,5,6]
	,["AAC","GSM","AAC lowbitrate","GSM lowbitrate","CELP","CELP lowbitrate", "PCM"]);

$pf_audio_channels= new PresetField_SUB_INT("AudioChannels", "Audio Channels", "channels", 2, [1,2,4,6,8,16]
	,["Mono","2-ch(Stereo)","4-ch","5.1ch","8-ch","16-ch"]);
$pf_audio_rate    = new PresetField_SUB_INT("SampleRate", "Audio Sampling Rate","samplerate", 48000,[44100,48000]//,96000]
	,["44.1k","48k"]);

$pf_prefqua  = new PresetField_ZERO_ONE("PreferQuality", "Prefered Quality", "codecPreferQuality", 0);
$pf_prefquaI = new PresetField_INT     ("PreferQualityI", "Prefered Quality I", "codecPreferQualityI", 0, 0,300);
$pf_prefquaP = new PresetField_INT     ("PreferQualityP", "Prefered Quality P", "codecPreferQualityP", 0, 0,300);
$pf_deinterr = new PresetField_ZERO_ONE("Deinterlace", "De-interlace", "deinterlace", 0);

$pf_recycleint = new PresetField_ZERO_ONE ("RecycleIntra", "Advanced Profile", "recycleintra", 0);
$pf_minimaxfi  = new PresetField_ZERO_ONE ("MinmaxFilter", "Min/Max Filter", "minmax-filter", 0);
$pf_softfilt   = new PresetField_ZERO_ONE ("SoftFilter", "Soft Filter", "soft-filter", 0);
$pf_ODCT       = new PresetField_ZERO_ONE ("ODCT", "ODCT Filter", "odct-filter", 0);


$pf_decIP = new PresetField_STR("decoderIP", "Decoder IP", "decoderip", "127.0.0.1");
$pf_decIP2= new PresetField_STR("decoderIP2", "Decoder IP2", "decoderip2", "");
$pf_decIP->_skip_in_preset = 1;
$pf_decIP2->_skip_in_preset = 1;

$pf_port  = new PresetField_INT_RANGE("port" , "TCP Port", "port" , 1802, 1, 2000*1000);
$pf_ttl  =  new PresetField_INT_RANGE     ("ttl" , "Multicast TTL", "ttl" , 1802, 1, 2000*1000);
$pf_packet_size  = new PresetField_INT_RANGE     ("packetsize" , "IP Packet size", "packetsize" , 1392, 1, 2000*1000);
$pf_stuffing = new PresetField_ZERO_ONE   ("stuffing", "Packet Stuffing", "enablestuffing", 1);
$pf_shuffle=   new PresetField_SUB_INT ("shuffle", "Shuffling", "shuffle", 0, [0,3,5,10,20], ["off","3","5","10","20"] );

$pf_ldmp_use     = new PresetField_SUB_INT ("ldmp-use", "Transport Protocol", "UseMPUDP", 1, [0,1], ["UDP","LDMP"]);
$pf_ldmp_manual  = new PresetField_ZERO_ONE("ldmp-manual" , "Manual LDMP", "ManualMPUDP" , 0);
$pf_ldmp_cwnd    = new PresetField_INT_RANGE("ldmp-cwnd",    "Cwnd", "MPUDP_CWND" , 200, 1, 20000);
$pf_ldmp_cwndmin = new PresetField_INT_RANGE("ldmp-cwndmin", "LDMP Min Cwnd", "MPUDP_CWND_MIN" , 200, 1, 20000);
$pf_ldmp_cwndmax = new PresetField_INT_RANGE("ldmp-cwndmax", "LDMP Max Cwnd", "MPUDP_CWND_MAX" , 200, 1, 20000);
$pf_ldmp_ackto   = new PresetField_INT_RANGE("ldmp-ackto" ,  "LDMP ACK Timeout", "MPUDP_ACK_TO" , 720, 1, 20000);
$pf_ldmp_sndto   = new PresetField_INT_RANGE("ldmp-sndto" ,  "LDMP Send Timeout", "MPUDP_SND_TO" , 2000, 1, 20000);
$pf_ldmp_rttm    = new PresetField_INT_RANGE("ldmp-rttm" ,   "RTT Multiplier", "JITTER_RTT_X" , 200, 1, 20000);
$pf_ldmp_jitter2 = new PresetField_INT_RANGE("ldmp-jitter2p","LDMP jitter %", "JITTER2_PERCENT" , 10, 0, 300);
$pf_ldmp_maxbrt  = new PresetField_INT_RANGE("ldmp-maxbrt",  "Shaping Percent", "MPUDP_MAX_BRT" , 120, 0, 300);


$pf_abn_maxbit   = new PresetField_INT_RANGE("abn_maxb",  "ABN Max Bitrate", "MaxBitrate" , 200, 1, 100*1000);
$pf_abn_time     = new PresetField_INT_RANGE("abn_time",  "ABN Time", "ABN_TIME" , 200, 1, 100*1000);
$pf_abn_avg      = new PresetField_INT ("abn_avg",  "ABN Average", "ABN_TIME" , 20);
$pf_abn_use      = new PresetField_ZERO_ONE("abn_useabn", "Use ABN", "useabn", 0);
$if_abn_status   = new PresetField_INT_RO("abn_status", "ABN Status", "abn_status", 0, 1);
$if_abn_bitrate  = new PresetField_INT_RO("abn_bitrate", "ABN Bitrate", "abn_bitrate", 0, 1);
$if_abn_max_delay = new PresetField_INT_RO("abn_max_delay", "ABN Max Delay", "abn_max_delay", 0, 1);
$if_abn_min_bitrate = new PresetField_INT_RO("abn_min_bitrate", "ABN Min bitrate", "abn_min_bitrate", 0, 1);
$if_abn_nettest_maxms = new PresetField_INT_RO("NetworkTestMaxMs", "Network Test Max (ms) ", "NetworkTestMaxMs", 0, 0);


// $phpSend->sendCommand("set::record::".$record_folder."/".$filename);

$pf_dynamicDemo = new PresetField_ZERO_ONE("DynamicStatus", "Dynamic Status", "codecDynamicDemo", 0);
$pf_watermark   = new PresetField_ZERO_ONE("Watermark", "Watermark", "codecWatermark", 0);

$pf_force2ch    = new PresetField_ZERO_ONE("force2ch", "Force 2ch", "abn_OverwriteAudio", 0);
$pf_restart_sync_loss=new PresetField_ZERO_ONE("restart_sync_loss","Restart On Sync Loss","encoder_restart_sync_loss",0);


// $pf_swapfield = new PresetField_ONOFF ("", "Swap field order", "ENCODER::VIDEO::SWAP FIELD", 0);

$pf_downcvt = new PresetField_ZERO_ONE("downconvert", "Downconvert", "downconvert", 0);

$pf_multiplex = new PresetField_SUB_INT("multiplex", "Multiplexing", "networkmultiplex", 0
	, [0,1,2]
	, ["Broadcast","Multiplex","Single"]
); #for UDP

$pf_dynamicRes  = new PresetField_INT_RANGE("DynamicRes", "Dynamic Resolution", "codecDynamicRes", 0, 0, 50000);
$pf_prv_overlay = new PresetField_ZERO_ONE ("PreviewOverlay", "Watermark on Preview", "EncoderPreviewOverlay", 0);
$pf_captimecode = new PresetField_ZERO_ONE ("CaptureTimeCode", "Capture TimeCode", "CaptureTimeCode", 0);


//$crypt_mode_label = [ "No" ,"AES-128" ,"AES-192" ,"AES-256" ,"GOST-15" ];
$crypt_mode_label = [ "No" ,"AES-128" ,"AES-192" ,"AES-256" ];
$pf_crypt_AES = new PresetField_ZERO_ONE("EnableAES", "AES Enabled?", "Feature::EnableAES", 0);
$pf_crypt_lim = new PresetField_INT("crypt_limit", "Encryption Limit", "EncryptionLimit", 0);
$pf_crypt_mode= new PresetField_SUB_INT("crypt_mode", "Encryption Mode", "EncryptionMode", 0,[0,1,2,3,4],$crypt_mode_label);
$pf_crypt_key = new PresetField_STR("crypt_key", "Encryption Key", "EncryptionKey", "");
$pf_crypt_AES->_read_only = 1;



########################################
#for decoder

//$inf_d_cur_bitrate = new PresetField("d_cur_bitrate", "Bitrate", "INFO::BITRATE", "N/A");
//$inf_lost_pkts = new PresetField_INT("lost_packets", "Lost Packets", "INFO::LOST", 0);
//$inf_recv_frames = new PresetField_INT("recv_frames", "Recoverd Frames", "INFO::RECOV", 0);
//$inf_dec_ip = new PresetField("d_IP", "Decoder IP", "INFO::IP", "N/A");
//$inf_crypt_state = new PresetField_SUB_INT("d_crypt_state", "Encryption State", "EncryptionState", 0
//	, [0,1,2,3,4]
//	, ["NO","AES128","AES192","AES256","GOST15"]
//);
//$inf_codec_err = new PresetField_ZERO_ONE("d_codec_error", "Codec Error", "codec_error", 0);
//$inf_codec_ver = new PresetField("d_codec_ver", "Codec Version", ":codec_version", "N/A");
/*
function set_ajt($v){
	return "set::network::autojittertimeout::" . $v;
};

function set_jitter1($v){
	$j = [ 0,5,10,30,50,100,300,500,800,1000,2000 ];
	if ($v<0 || count($j)>$v) return "";
	//return "set::jitter::" . $v;
	return "set::jitter::" . $j[$v];
}
function set_jitter2($v){
	$j = [ 0,5,10,30,50,100,300,500,800,1000,2000 ];
	if ($v<0 || count($j)>$v) return "";
	return "set::jitter2::" . $j[$v];
}
*/

$pf_ip_mode   = new PresetField_IP_MODE("ip_mode", "IP Mode", "NETWORK", 0, [0,1], ["IP","IP Multicast"]);
$pf_multicast_ip = new PresetField("multicast_ip", "Multicast IP", "MulticastIP", "127.0.0.1");
$pf_aj_timeout = new PresetField_INT("aj_timeout", "Timeout", "network::a-j-timoute", 0);
//$pf_aj_timeout->_set_cmd_ = set_ajt;
$pf_aj_timeout->_set_cmd_ = function ($v){ return "set::network::autojittertimeout::" . $v; };

// 0,5,10,30,50,100,300,500,800,1000,2000
$pf_jitter1 = new PresetField_JITTER("jitter1", "Jitter", "jitter", 0, [0,1,2,3,4,5,6,7,8,9,10], ["0","5","10","30","50","100","300","500","800","1000","2000"]);
$pf_jitter2 = new PresetField_JITTER("jitter2", "Jitter2","jitter2",0, [0,1,2,3,4,5,6,7,8,9,10], ["0","5","10","30","50","100","300","500","800","1000","2000"]);
//$pf_jitter1->_set_cmd_ = set_jitter1;
//$pf_jitter2->_set_cmd_ = set_jitter2;
//$pf_dec_port  = new PresetField_INT("dec_port" , "Port", "port" , 1770);
$pf_dec_port  = new PresetField_INT_RANGE("dec_port" , "Port", "port" , 1770, 1025, 65535);


function get_L3orL5($pf=null, $encp=null){
	if (file_exists('/var/lib/avenir/ACTL5')) return "ACT-L5";
	return "ACT-L3";
}

function get_sys_ver($pf=null, $encp=null){
	$AVESYSVERFILE='/var/lib/avenir/SYS_VERSION';
	if (file_exists($AVESYSVERFILE)){
		$f = fopen($AVESYSVERFILE,'r');
		if ($f){
			$AVE_VER = fread($f,1000);
			fclose($f);
		}
		return trim($AVE_VER) ;
	}
	return "N/A";
}

function get_SN($pf=null, $encp=null){
		$conn = new IXR_Client('http://localhost:1912/');
		$r = $conn->query('getSN');
		if ($r) return $conn->getResponse();
		return "N/A";
}

$inf_sys_ver  = new PresetField_STR_RO("sys_ver","Systerm Version","","");
$inf_sys_sn   = new PresetField_STR_RO("sys_sn","Systerm Serial","","");
//$inf_l3_or_l5 = new PresetField_STR_RO("l3_or_l5","Codec Selection","","");
$inf_l3_or_l5 = new PresetField_STR_RO("l3_or_l5","System Default Codec","","");

//$inf_sys_ver->_get_ex_cmd_ = function($pf, $e){ return get_sys_ver($pf,$e) ; };
$inf_sys_ver->_get_ex_cmd_ = "get_sys_ver"; // it's the way to set function pointer inn php ?
$inf_sys_sn->_get_ex_cmd_ = function ($pf, $e){
	$conn = new IXR_Client('http://localhost:1912/');
	$r = $conn->query('getSN');
	if ($r) return $conn->getResponse();
	return "";
};

$inf_l3_or_l5->_get_ex_cmd_ = function ($pf, $e){
	if (file_exists('/var/lib/avenir/ACTL5')) return "ACT-L5";
	return "ACT-L3";
};


//$pf_auto_jitter = new PresetField_ON_OFF("auto_jitter", "Auto Jitter", "network::autojitter", 0);
$pf_auto_jitter->_set_ex_cmd_ = function ($pf, $encpt, $v){
	$rr = $encpt->sendCommand($pf->getCmd());
	$rr = $rr['result'];
	$r = $pf->parse($rr);
	if ($r == $v) return;
	$cmds = $pf->setCmds($v);
	if (! $cmds) return;
	foreach($cmds as $cmd) $encpt->sendCommand($cmd);
};

function _if_pull_ready(){
	global $pullobj;
	$fname = $pullobj->get_pull_filename(0);
	if (file_exists($fname)) return 1;
	return 0;
}

$inf_pull_ready = new PresetField_ZERO_ONE("inf_pull_ready", "Is PULL Ready?", "is_pull", 0);
$inf_pull_ready->_read_only = 1;
$inf_pull_ready->_get_ex_cmd_ = "_if_pull_ready";





$pull_fld_list = outLiveIPTable();
$pull_labels  = array();
$pull_indexes = array();

for($i=0; $i<count($pull_fld_list); $i++){
	$a = $pull_fld_list[$i];
	$c  = $a[0];
	$ip = $a[1];
	$name = $a[2];
	$pull_indexes[] = $i;
	$pull_labels[]  = $name . " (" . $c . ")";
}


//function aaaa(){
//global $pullobj;


//$pf_auto_jitter = new PresetField_ON_OFF("auto_jitter", "Auto Jitter", "network::autojitter", 0);
function get_nif_info($pf, $encpt, $v){
	$rr = $encpt->sendCommand("get::stats_num_int");
	$nif = intval($rr['result']);
	if ($nif<=0) return "";
	$r = array();
	for ($i=0; $i<$nif; $i++){
		$r2 = array();
		$rr = $encpt->sendCommand("get::stats_int_status::".$i); //ON/OFF
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_name::".$i);   // N/A?
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_ip::".$i);    // IPv4
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_provider::".$i); // ??
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_bitarte::".$i);  // Kbps
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_loss::".$i);     // loss(%) 0.0%
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_jitter::".$i);   // jitter (ms)
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_oo::".$i);       // out-of-order packets
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_delay::".$i);    // Delay (ms)
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::NETWORK::jitter::".$i);    // jitter1
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::NETWORK::jitter2::".$i);   // jitter2
		$r2[] = $rr['result'];
		$rr = $encpt->sendCommand("get::stats_int_maxdelay::".$i); // Max Delay (ms)
		$r2[] = $rr['result'];
		$r[] = $r2;
	}
	return $r;
};
$inf_dec_nif_stat  = new PresetField_CUSTOM_RO("inf_dec_nif_stat" , "I/F Stat", "" , "");
$inf_dec_nif_stat->_get_ex_cmd_ = "get_nif_info";




function get_audiolevels($pf, $encpt, $v){
	$r = array(0);
	$rr = $encpt->sendCommand("get::audiolevels");
	$s = $rr['result'];
	if (count($s)<=0) return $r;
	$tk = explode(":", $s);
	for($i=0; $i<count($tk); $i++){
		$tk[$i] = intval($tk[$i]);
	}
	if (count($tk)==0) return $r;
	if (count($tk)==($tk[0]+1)){
		return $tk;
	} else {
		$tk[0] = count($tk)-1;
	}
	return $tk;
}
//$inf_audiolevels->_get_ex_cmd_ = get_audiolevels;


class Pullobj {
	var $cur_val = null;

	function get_dec_id(){
		if (array_key_exists("ENC_PORT", $GLOBALS)) global $ENC_PORT;
		else $ENC_PORT = 1801;
		$dec_id = $ENC_PORT - 1801;
		if ($dec_id<0) return 0;
		return $dec_id;
	}

	function if_pull_ready(){
		$fname = $this->get_pull_filename(0);
		if (file_exists($fname)) return 1;
		return 0;
	}

	function get_pull_filename($b=1){
		$dec_id = $this->get_dec_id();
		$pullfile = "/var/lib/avenir/PULL_DEC.xml";
		if ($dec_id>0) $pullfile = sprintf("/var/lib/avenir/PULL_DEC_%d.xml", $dec_id);
		if ($b==0) return $pullfile;
		if (! file_exists($pullfile)){
			$pullfile = $pullfile . ".bak";
		}
		return $pullfile;
	}

	function to_bk(){
		$pullfile = $this->get_pull_filename(0);
		if (file_exists($pullfile)) rename($pullfile,  $pullfile . ".bak");
	}

	function to_fb(){
		$pullfile = $this->get_pull_filename(0);
		if (file_exists($pullfile)) return;
		$pullfile2 = $pullfile . ".bak" ;
		if (file_exists($pullfile2) && !file_exists($pullfile) ) rename($pullfile2, $pullfile);
	}

	function read_1(){
		if ($this->cur_val) return $this->cur_val;
		$pullfile = $this->get_pull_filename();
		if (! file_exists($pullfile)) return;
		$dom = new domdocument('1.0','UTF-8');
		if (!$dom->load($pullfile)){
			// invalid XML file?
			return;
		}
		$el = $dom->getElementsByTagName('pulldec');
		if (!$el){
			// element not found
			return;
		}

		$e = $el->item(0);
		if (!$e){ // unexpected error
			return;
		}

		$r = array();
		foreach(array("ip","port","login","pwd","drm","reporter") as $name){
			$value = $e->getAttribute($name);
			$r[] = $value;
		}

		$this->cur_val = $r;
		$this->ip    = $r[0];
		$this->port  = intval($r[1]);
		$this->login = $r[2];
		$this->pwd   = $r[3];
		$this->drm   = $r[4];
		//$this->reporter = $r[5];
		return $r;
	}

	function save(){
		$pullfile = $this->get_pull_filename(0);
		$r = $this->cur_val;
		if (!$r) return;
		$ip    = $r[0];
		$port  = $r[1];
		$login = $r[2];
		$pwd   = $r[3];
		$drm   = $r[4];
		//$reporter = $r[5];

		$dom = new domdocument('1.0','UTF-8');
		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;
		$root = $dom->createElement('root');
		$root->setAttribute("platform", "linux");
		$dom->appendChild($root);
		//$dom->loadXML($rt1);
		//if(!$dom->load($AvenirSettings))

		$e = $dom->createElement('pulldec');
		$root->appendChild($e);
		$e->setAttribute("ip", $ip);
		$e->setAttribute("port", $port);
		$e->setAttribute("login", $login);
		$e->setAttribute("pwd", $pwd);
		$e->setAttribute("drm", $drm);
		//$e->setAttribute("reporter", $reporter);

		//$this->to_bk();
		$dom->save($pullfile);
		chmod($pullfile, 0666);
	}

	function get($k, $d=null){
		$this->read_1();
		$idx = array_search($k, array("ip","port","login","pwd","drm","reporter"));
		if ($idx===false) return $d;
		if (!$this->cur_val) return $d;
		return $this->cur_val[$idx];
	}

	function set($k, $v){
		$d = -1;
		$idx = array_search($k, array("ip","port","login","pwd","drm","reporter"));
		if ($idx===false) return $d;
		$this->read_1();
		if (! $this->cur_val) $this->cur_val = ["","","", "","",""];
		$this->cur_val[$idx] = $v;
		// save ?
		$this->save();
	}

};

$pullobj = new Pullobj();

function get_pull_field($pf, $encpt){
	global $pullobj;
	$cb = $pf->cmd_base;
	$r = $pullobj->get($cb);
	return $r;
}

function set_pull_field($pf, $encpt, $v){
	global $pullobj;
	$cb = $pf->cmd_base;
	$pullobj->set($cb, $v);
}

class PF_Pull_fld extends PresetField_STR {
	function __construct($cn, $l, $cmd, $dv ){
		parent::__construct($cn, $l, $cmd, $dv);
		$this->_get_ex_cmd_ = "get_pull_field";
		$this->_set_ex_cmd_ = "set_pull_field";
	}
};


$inf_pull_srv= new PresetField_SUB_INT("inf_pull_srv", "Mode", "", 0, $pull_indexes, $pull_labels);
//$inf_pull_srv->_read_only = 1;

$inf_pull_ip   = new PF_Pull_fld("inf_pull_ip", "IPv4", "ip", "");
$inf_pull_port = new PF_Pull_fld("inf_pull_port", "Port", "port", "");
$inf_pull_login = new PF_Pull_fld("inf_pull_login", "Login", "login", "");
$inf_pull_pwd   = new PF_Pull_fld("inf_pull_pwd", "Password", "pwd", "");
$inf_pull_drm   = new PF_Pull_fld("inf_pull_drm", "Group/DRM", "drm", "");
$inf_pull_reporter = new PF_Pull_fld("inf_pull_reporter", "Reporter", "reporter", "");



$readonlyList = [

	$inf_dec_ip
	,$inf_bitrate
	,$inf_lost_packets
	,$inf_recov_frames
	,$inf_cjitter
	,$inf_cjitter2
	,$inf_field_order
	,$inf_codec_ver
	,$inf_crypt_state
	,$inf_crypt_warn
	,$inf_codec_error
	,$inf_feature_error
	,$inf_meta_title
	,$inf_meta_location
	,$inf_meta_reporter
	,$inf_video
	,$inf_audio
	,$inf_color_prof
	,$inf_fec
	,$inf_ishuffle
	,$inf_dolby_vision

	,$inf_insignal
	,$inf_netmode
	,$inf_cur_bitrate
	,$inf_isstream
	,$inf_isrecord
	,$inf_abnstatus
	,$inf_sdi_error
	,$inf_dropcapt
	,$inf_dropenc
	,$inf_quality
	,$inf_framedelay
	,$inf_shuffle
	,$inf_buffer
	,$inf_bytes
	,$inf_sentpacket
	,$inf_captDolbyRaw
	,$inf_dolbyInfoPre
	,$inf_pkt_size
	,$inf_decoder_ip1
	,$inf_decoder_ip2
	,$inf_encoder_ip1
	,$inf_encoder_ip2
	,$inf_is_ldmp 
	,$inf_isrestart
	,$pf_crypt_lim
	,$pf_crypt_AES
];
foreach($readonlyList as $i){ $i->_read_only = 1; }


$pf_base_set = [
	 $pf_bitrate,$pf_framerate,$pf_keyframe,$pf_vbr,$pf_fec,$pf_colorProf,$pf_colorSpace,$pf_bitdepth
	,$pf_reso

	,$pf_audio_codec, $pf_audio_channels, $pf_audio_rate

	,$pf_ldmp_use ,$pf_ldmp_manual ,$pf_ldmp_cwnd,$pf_ldmp_cwndmin,$pf_ldmp_cwndmax
	,$pf_ldmp_ackto,$pf_ldmp_sndto,$pf_ldmp_rttm,$pf_ldmp_jitter2,$pf_ldmp_maxbrt

	,$pf_prefqua  ,$pf_prefquaI ,$pf_prefquaP ,$pf_deinterr
	,$pf_recycleint ,$pf_minimaxfi  ,$pf_softfilt   ,$pf_ODCT

	,$pf_decIP ,$pf_port  ,$pf_ttl  ,$pf_packet_size  ,$pf_stuffing ,$pf_shuffle

	,$pf_meta_tit ,$pf_meta_loc ,$pf_meta_rep ,$pf_meta_pro ,$pf_meta_drm

	,$pf_dynamicRes ,$pf_dynamicDemo ,$pf_watermark

	// ,$pf_video_source ,$pf_audio_input

	//,$pf_force3d, $pf_logdrop
	, $pf_prv_overlay, $pf_dynamicRes
	//, $pf_decIP2

	,$inf_insignal
	,$inf_netmode
	,$inf_cur_bitrate
	,$inf_isstream
	,$inf_isrecord
	,$inf_isrestart
	,$inf_abnstatus
	,$inf_sdi_error
	,$inf_dropcapt
	,$inf_dropenc
	,$inf_quality
	,$inf_framedelay
	,$inf_shuffle
	,$inf_buffer
	,$inf_bytes
	,$inf_sentpacket
	,$inf_captDolbyRaw
	,$inf_dolbyInfoPre
	,$inf_pkt_size 
	,$inf_decoder_ip1
	,$inf_decoder_ip2
	,$inf_encoder_ip1
	,$inf_encoder_ip2
	,$inf_is_ldmp
	,$pf_multiplex

	,$pf_crypt_AES, $pf_crypt_lim, $pf_crypt_mode, $pf_crypt_key

	,$inf_enc_ver,$inf_builddate

	,$pf_abn_maxbit
	,$pf_abn_time
	,$pf_abn_avg
	,$pf_abn_use
	,$if_abn_status
	,$if_abn_bitrate
	,$if_abn_max_delay
	,$if_abn_min_bitrate
	,$if_abn_nettest_maxms

	,$pf_force2ch, $pf_restart_sync_loss

	,$inf_audiolevels
	,$inf_audiolevel

	// for decoder

	,$inf_dec_ip
	,$inf_bitrate
	,$inf_lost_packets
	,$inf_recov_frames
	,$inf_cjitter
	,$inf_cjitter2
	,$inf_field_order
	,$inf_codec_ver
	,$inf_crypt_state
	,$inf_crypt_warn
	,$inf_codec_error
	,$inf_feature_error
	,$inf_meta_title
	,$inf_meta_location
	,$inf_meta_reporter
	,$inf_video
	,$inf_audio
	,$inf_color_prof
	,$inf_fec
	,$inf_ishuffle
	,$inf_dolby_vision

	,$pf_auto_jitter 
	,$pf_ip_mode
	,$pf_multicast_ip
	,$pf_aj_timeout
	,$pf_jitter1
	,$pf_jitter2
	,$pf_dec_port

	,$inf_sys_ver
	,$inf_sys_sn
	,$inf_l3_or_l5

	,$inf_pull_srv
	,$inf_pull_ip
	,$inf_pull_port
	,$inf_pull_login
	,$inf_pull_pwd
	,$inf_pull_drm
	,$inf_pull_reporter
	,$inf_pull_ready

	,$inf_dec_vid
	,$inf_dec_nif
	,$inf_dec_nif_stat

];


$PRESET_CAT_LIST_INFO = [
	"decoder_ip", 
	"bitrate", "lost_packets", "recov_frames", "cjitter", "cjitter2", "field_order", "codec_ver", 
	"crypt_state", "crypt_warn", "codec_error", "feature_error", 
	"meta_title", "meta_location", "meta_reporter", 
	"video", "audio", 
	"color_prof", "fec", "ishuffle", 
	"dolby_vision" 
	,"inf_pull_ready"
	,"inf_dec_vid"
	,"inf_dec_nif"
	,"inf_dec_nif_stat"
/*
	"inputsignal","cnetworkmode","cur_bitrate", "isStreaming", "isRecording"
	,"isRestarting"
	, "abn_status", "sdi_error", "dropCapture", "dropEnc"
	,"vquality", "frame_delay", "cshuffle", "cbuffer", "cbytes", "sent_packets"
	//,"captureDolbyRaw", "dolbyInfoPresent"
	, "c_packetsize"
	,"c_decoderIP", "c_decoderIP2", "c_encoderIP", "c_encoderIP2"
	, "is_ldmp"
*/
];

$PRESET_CAT_LIST_NET = [
	"ip_mode"
	,"multicast_ip"
	,"auto_jitter"
	,"aj_timeout"
	,"jitter1"
	,"jitter2"
	,"dec_port"
];

$PRESET_CAT_LIST_VER = [
	"version", "build_date"
	,"sys_ver"
	,"sys_sn"
	,"l3_or_l5"
];


$PRESET_CAT_LIST_ENC = [
	 "TargetBitrate"
	,"Resolution","ColorSpace","NativeColorSpace"
	,"KeyFrame"
	,"BitDepth","FrameRate"
	,"RecycleIntra"
	,"PreferQuality","PreferQualityI","PreferQualityP"
	,"Deinterlace","MinmaxFilter","SoftFilter","ODCT"
	,"DynamicStatus", "DynamicRes"
	,"AudioCodec" ,"AudioChannels","SampleRate"
];

/*
$PRESET_CAT_LIST_NET = [
	//"TargetBitrate"
	 "decoderIP"
	,"VBR"
	,"port"
	,"packetsize"
	,"ttl"
	,"FEC"
	,"stuffing"
	,"shuffle"
];
*/

$PRESET_CAT_LIST_TPT = [
  "ldmp-use","ldmp-manual","ldmp-cwnd","ldmp-cwndmin","ldmp-cwndmax"
 ,"ldmp-ackto","ldmp-sndto","ldmp-rttm","ldmp-jitter2p","ldmp-maxbrt"
 // for UDP
 , "multiplex"
];

$PRESET_CAT_LIST_VAI = [
  "video_source","audio_input"
];

$PRESET_CAT_LIST_META = [
  "Meta_Network1"
  ,"Meta_Slug","Meta_Location","Meta_Reporter","Meta_Producer"
];

$PRESET_CAT_LIST_VID = [
	 "TargetBitrate"
	,"Resolution","ColorSpace","NativeColorSpace"
	,"KeyFrame"
	,"BitDepth","FrameRate"
	,"RecycleIntra"
	,"PreferQuality","PreferQualityI","PreferQualityP"
	,"Deinterlace","MinmaxFilter","SoftFilter","ODCT"
	,"DynamicStatus", "DynamicRes"
];

$PRESET_CAT_LIST_AUD = [
  "AudioCodec","AudioChannels","SampleRate"
];


$PRESET_CAT_LIST_PULL = [
	 "inf_pull_srv"
	,"inf_pull_ip"
	,"inf_pull_port"
	,"inf_pull_login"
	,"inf_pull_pwd"
	,"inf_pull_drm"
	,"inf_pull_reporter"
];

$PRESET_CAT_LIST_INPUT = [
	 "AudioInput"
	,"VideoInput"
];

$PRESET_CAT_LIST_AVMISC = [
	 "PreviewOverlay"
	# ,"Force3D"
];

$PRESET_CAT_LIST_CRYPT = [
	"EnableAES", "crypt_limit","crypt_mode","crypt_key"
];


$PRESET_CAT_LIST_AUL = [
	//"audiolevels", "audiolevel"
	"audiolevels"
];


$PRESET_CAT_LIST_DICT = [
	 1  =>  $PRESET_CAT_LIST_ENC    #0
	,2  =>  $PRESET_CAT_LIST_NET    #1
	,4  =>  $PRESET_CAT_LIST_VAI    #2
//	,8  =>  $PRESET_CAT_LIST_META   #3
//	,16 =>  $PRESET_CAT_LIST_TPT    #4
//	,32 =>  $PRESET_CAT_LIST_VID    #5
//	,64 =>  $PRESET_CAT_LIST_AUD    #6
	,128 => $PRESET_CAT_LIST_INPUT  #7
	,256 => $PRESET_CAT_LIST_AVMISC #8
	,512 => $PRESET_CAT_LIST_CRYPT 
	,1024 => $PRESET_CAT_LIST_INFO 
	,4096 => $PRESET_CAT_LIST_VER
	,8192 => $PRESET_CAT_LIST_PULL
	,16384 => $PRESET_CAT_LIST_AUL
];

$PRESET_CAT_BIT_DICT = [
	 "codecs" => 1
	,"network" => 2
	,"metadata" => 8
	,"transport" => 16
	,"video" => 32
	,"audio" => 64
	,"encryption" => 512
	,"status"    => 1024
	//,"presets" => 2048
	,"version"   => 4096
	,"ver"       => 4096
	,"pull"       => 8192
	,"audiolevels" => 16384
];



class PFMan {
	var $cat_list = ["status", "video", "audio", "network", "transport", "metadata", "encryption", "presets", "pull"];

	function __construct(){
		global $PRESET_CAT_BIT_DICT;
		$this->cat_list = array_keys($PRESET_CAT_BIT_DICT);
	}

	function getCatNameList(){
		return $this->cat_list;
	}


	function getCmdList_url($_URL){
		global $PRESET_CAT_BIT_DICT ;
		#$_URL = $_REQUEST["_url"];
		$upl = explode("/", $_URL);
		$l = count($upl);
		if ($l>=1 && ! $upl[$l-1]) unset($upl[$l-1]);

		$l = count($upl);
		if (!$l){
			// no category name
			return null;
		}
		$catname = $upl[0];

		if (! in_array($catname, $this->cat_list)){
			// not exists in cat_name_list
			return null;
		}
		$catBit = $PRESET_CAT_BIT_DICT[$catname];
		if (!$catBit){
			// not exists in cat_name_list
			return null;
		}
		//print "$catBit \n";

		return $this->getPFList($catBit);
	}


	function getPFList($catBit){
		global $pf_base_set;
		global $PRESET_CAT_LIST_DICT ;

		$r = [];
		for($b=1; $b <= 65536; $b<<=1){
			if (!($b & $catBit)) continue;
			$pf_names = $PRESET_CAT_LIST_DICT[$b];
			foreach($pf_names as $i){
				foreach($pf_base_set as $j){
					if ($i == $j->cname){
						$r[] = $j;
						break;
					}
				}
			}
		}
		//echo count($r), "\n";
		return $r;
	}



	function getAllCmds(){
		return $this->getPFList(0xFFFFFFFF);
	}




	function getCmdList_test($t){
		//TODO: $t: flag to choose category
		global  $pf_vbr ,$pf_meta_tit ,$pf_meta_loc ,$pf_meta_rep ,$pf_meta_drm  ;
		global $pf_bitrate
			,$pf_framerate
			,$pf_keyframe
			,$pf_colorProf
			,$pf_colorSpace
			,$pf_framerate
			,$pf_vbr
			,$pf_fec
		;

		return [
			 $pf_bitrate
			,$pf_framerate
			,$pf_keyframe
			,$pf_colorProf
			,$pf_colorSpace
			,$pf_framerate
			,$pf_vbr
			,$pf_fec

			,$pf_meta_tit
			,$pf_meta_loc
			,$pf_meta_rep
			,$pf_meta_drm
		];
	}

	function fetchResults($encpt, $cmdlist){
		$r = [];
		if (!$cmdlist) $cmdlist = [];
		foreach ($cmdlist as $i){
			if ($i->_get_ex_cmd_){
				$v = ($i->_get_ex_cmd_)($i, $encpt);
			} else {
				$rr = $encpt->sendCommand($i->getCmd());
				$rr = $rr['result'];
				$v = $i->parse($rr);
			}
			$_item = [
				"cname" => $i->cname
				,"type" => $i->pftype
				,"label" => $i->label
				,"val" => $v
			];
			if ($i->pftype==_PF_TYPE_SUB_INT){
				$_item["sub_values"] = $i->val_set;
			}
			$vlist = $i->getLabelList();
			if ($vlist){
				$_item["val_labels"] = $vlist ;
			}
			$_item["read_only"] = $i->_read_only;

			if ($i->pftype==_PF_TYPE_INT_RANGE){
				$_item["vmin"] = $i->low ;
				$_item["vmax"] = $i->high ;
			}

			$r[] = $_item;
		}
		return $r;
	}


	function setAll($encpt, $vallist){
		$n = 0;
		$cmdlist = $this->getAllCmds();
		$cmdDict = [];
		foreach ($cmdlist as $i) $cmdDict[$i->cname] = $i;

		foreach ($vallist as $i){
			$cname = $i["cname"];
			$v     = $i["val"  ];
			if (!$cname) continue;
			$pf = $cmdDict[$cname];
			if (! $pf) continue;
			//print "$cname => $v \n";
			//$v = $pf->parse($v); // no need to parse, as JSON already transform type
			// if ($v is not valid) continue;
			if ($pf->_set_ex_cmd_){
				($pf->_set_ex_cmd_)($pf, $encpt, $v);
				//$n++;
				continue;
			}
			$cmds = $pf->setCmds($v);
			//echo "cmd: ", $cmd, "\n";
			if (! $cmds) continue;
			foreach($cmds as $cmd)
				$encpt->sendCommand($cmd);
			$n++;
		}
		return $n;
	}

	function wait4restarting($encpt){
		$isRestarting = 0;
		$nWaits = 0;
		while (1){
			$r = $encpt->sendCommand("isrestarting"); 
			switch($r['result']){
			  case "unsupported":
				$isRestarting = -1;
				usleep(300000);
				break;
			  case 1:
				$isRestarting = 1;
				$nWaits++;
				break;
			  case 0:
				$isRestarting = 0;
				break;
			  default:
				$isRestarting = -1;
				break;
			}
			////
			if ($isRestarting==0 || $isRestarting==-1 || $nWaits>800){
				break;
			}
			usleep(200000);
		}
	}

	function action($encpt, $alist){
		global $pullobj;
		$r = 0;
		//$enccmd_list=["start","stop", "restart","abnstart", "abnstart1", "abnstop", "abn_cancel"];
		$enccmd_list=["restart"];
		foreach ($alist as $a){
			if (in_array($a, $enccmd_list)){
				$encpt->sendCommand($a);
				continue;
			}elseif ($a=="wait4restart"){
				$this->wait4restarting($encpt);
				continue;
			}elseif ($a=="start_pull"){
				//TODO:
				$pullobj->to_fb();
				$_dec_id = $pullobj->get_dec_id();
				$conn = new IXR_Client('http://localhost:1912/');
				if ($_dec_id>0){
					$conn->query('opEachDec', $_dec_id, 'stop');
					$conn->query('opEachPullDec', $_dec_id, 'restart');
				} else {
					//$conn->query('opEachPullDec', 0, 'stop');
					$conn->query('opAppService', "streambox-decoder-trad", 'stop');
					$conn->query('opAppService', "streambox-pull-decoder", 'restart');
				}
			}elseif ($a=="start_normal"){
				//TODO:
				$pullobj->to_bk();
				$_dec_id = $pullobj->get_dec_id();
				$conn = new IXR_Client('http://localhost:1912/');
				if ($_dec_id>0){
					$conn->query('opEachPullDec', $_dec_id, 'stop');
					$conn->query('opEachDec', $_dec_id, 'restart');
				} else {
					$conn->query('opEachPullDec', 0, 'stop');
					$conn->query('opAppService', "streambox-pull-decoder", 'stop');
					$conn->query('opAppService', "streambox-decoder-trad", 'restart');
				}
			}
			if (preg_match("/^msleep:(\\d+)$/", $a, $m)){
				$t = intval($m[1]);
				if ($t>0 && $t<=10*1000) usleep($t*1000);
			}
		}
		return $r;
	}

};


function _test_pf_category_integration_test(){
	global $PRESET_CAT_LIST_DICT;
	global $pf_base_set;
	foreach ([1,2,4,8,32,64,128,256] as $i){
		print "\ncategory $i ...\n";
		$title_list = $PRESET_CAT_LIST_DICT[$i];
		//print_r($title_list);
		foreach($title_list as $j){
			$_found = 0;
			$cname = $j;
			print("checking $cname ..\n");
			foreach($pf_base_set as $k){
				if ($cname == $k->cname){
					$_found = 1;
					break;
				}
			}

			if (!$_found){
				print("\t##ERR: cat[$i] $cname Not Found\n");
			}

		}

	}
}



# _test_pf_category_integration_test();


function _test_check_global_SERVER_for_URLPARAM(){
	print "\n";
	print_r($_SERVER["REDIRECT_URL"]);
	print "\n";
	print_r($_SERVER["REDIRECT_QUERY_STRING"]);
	print "\n";
	print_r($_SERVER["QUERY_STRING"]);
	print "\n";
	print_r($_SERVER["REQUEST_URI"]);
	print "\n";
	print_r($_REQUEST);
	print "\n";
	print_r($_REQUEST["_url"]);
	print "\n";
	$_URL = $_REQUEST["_url"];
	$up = explode("/", $_URL);
	print_r($up);
	print "\n";
	print_r($_SERVER);
}



//$cat_list = [ "status", "video", "audio", "network", "transport", "metadata", "encryption", "presets" ];



// encoder/status
// encoder/video
// encoder/audio
// encoder/network
// encoder/transport
// encoder/metadata
// encoder/encryption
// encoder/presets
// encoder/preview/JPG
// encoder/preview/BMP
// encoder/features
// encoder/features/new
// encoder/action




/*********************************************************************************
 RFC2253 (UTF-8 String Representation of Distinguished Names):

String  X.500 AttributeType
------------------------------
CN      commonName
L       localityName
ST      stateOrProvinceName
O       organizationName
OU      organizationalUnitName
C       countryName
STREET  streetAddress
DC      domainComponent
UID     userid
DN      (Distinguished Name) (ex. "DC=gp,DC=gl,DC=google,DC=com")

What does the string from that query mean?

The string ("CN=Dev-India,OU=Distribution Groups,DC=gp,DC=gl,DC=google,DC=com")
*********************************************************************************/


//if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {}
/*
CYGWIN_NT-5.1
Darwin
FreeBSD
HP-UX
IRIX64
Linux
NetBSD
OpenBSD
SunOS
Unix
WIN32
WINNT
Windows
*/


?>
