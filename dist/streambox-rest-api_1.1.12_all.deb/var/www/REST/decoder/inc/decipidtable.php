<?php

$_no_liveip_filter = 1;


function read_live_serer_xml(){
	$_r = array();

	$flist = array(
		 "/usr/share/streambox/avenir/conf/liveServers.xml"
		,"/usr/share/streambox/avenir/conf/extraLiveServers.xml"
		,"/var/lib/avenir/extraLiveServers.xml"
		,"/usr/share/streambox/avenir/conf/extraVMServers.xml"
		,"/var/lib/avenir/extraVMServers.xml"
	);

	foreach($flist as $i){
		if (!file_exists($i)) continue;
		$d = simplexml_load_file($i);
		if ($d){ foreach($d as $j) $_r[] = $j; }
	}
	return $_r;
}

function read_live_serer_xml_obsolete(){
	$d1= simplexml_load_file("/usr/share/streambox/avenir/conf/liveServers.xml");
	$d2= simplexml_load_file("/var/lib/avenir/extraLiveServers.xml");
	$d3= simplexml_load_file("/usr/share/streambox/avenir/conf/extraLiveServers.xml");

	// How to merge simplexml object?
	$_d = array();
	if ($d1){ foreach($d1 as $i) $_d[] = $i; }
	if ($d2){ foreach($d2 as $i) $_d[] = $i; }
	if ($d3){ foreach($d3 as $i) $_d[] = $i; }
	$d = $_d;

	return $d;
}


function outLiveIPIDTable(){
	global $_no_liveip_filter;
	$r = array();

	$t = Array(
		 Array("Oregon", "A")
		,Array("LiveUSE", "B")
		,Array("LiveAU", "C")
		,Array("LiveDE", "E")
		,Array("LiveEU", "F")
		,Array("LiveJP", "G")
		,Array("LiveSA", "H")
		,Array("LiveSG", "I")
		,Array("LiveIN", "J")
		,Array("LiveHK", "HK")
		,Array("LivePost", "P")
	);
	$livePostIP = "52.8.239.106";

	//$d = simplexml_load_file("/usr/share/streambox/avenir/conf/liveServers.xml");
	$d = read_live_serer_xml();

	foreach ($d as $i){
		$ip   = "".$i['ip'];
		$name = "". $i->name ;
		#print_r( $ip . "\n" );
		#print_r( $name . "\n" );
		#print_r( strpos($name, "Oregon")!==FALSE);
		#
		#$name2 = ''. $i->name3;
		#print $name2 . "\n";

		$p = "". $i['sessID'];

		if ($_no_liveip_filter && $p){
			$r[$p] = $ip;
		} else {
			foreach ($t as $i){
				$n = $i[0];
				$p = $i[1];
				if (strpos($name, $n)!==FALSE){
					$r[$p] = $ip;
					break;
				}
			}
		}
	}

	if (!array_key_exists("P", $r)){
		$r["P"] = $livePostIP;
	}

	#print_r($r);
	return $r;
}


function outLiveIPTable(){
	global $_no_liveip_filter;
	$r = array();

	$t = Array(
		 Array("Oregon",   "A")
		,Array("LiveUSE",  "B")
		,Array("LiveAU",   "C")
		,Array("LiveDE",   "E")
		,Array("LiveEU",   "F")
		,Array("LiveJP",   "G")
		,Array("LiveSA",   "H")
		,Array("LiveSG",   "I")
		,Array("LiveIN",   "J")
		,Array("LiveHK",   "HK")
		,Array("LivePost", "P")
		//
		,Array("vmNetflix", "N")
		,Array("vmCO3", "3")
	);
	#$livePostIP = "52.8.239.106";

	//$d = simplexml_load_file("/usr/share/streambox/avenir/conf/liveServers.xml");
	$d = read_live_serer_xml();

	foreach ($d as $i){
		$ip   = "".$i['ip'];
		$name = "". $i->name ;
		$name2 = ''. $i->name3;
		if ($name2) $name = $name2;

		$p = "". $i['sessID'];

		if ($_no_liveip_filter){
			$r[] = array( $p, $ip , $name);
		} else {
			foreach ($t as $i){
				$n = $i[0];
				$p = $i[1];
				if (strpos($name, $n)!==FALSE){
					$r[] = array( $p, $ip , $name);
					break;
				}
			}
		}
	}

	/////////////////////////////////
	if (0){
		$spcs = Array(
			 Array("vmNetflix", "vmNetflix.streambox.com", "70.224.197.250", "N")
			,Array("vmCO3", "vmCO3.streambox.com","70.224.197.94", "3")
		);
		foreach($spcs as $i){
			$rrr = 1;
			foreach($r as $ri){ if ($ri[0]==$i[3]) $rrr = 0; }
			if ($rrr==1)
				$r[] =  array( $i[3], $i[2], $i[0]);
		}
	}
	/////////////////////////////////

	#print_r($r);
	return $r;
}

function _output_pull_server_js(){
	print "var decIPIDTable = {};\n";
	foreach( outLiveIPIDTable() as $k => $v){
		echo "decIPIDTable['". $k . "'] = '". $v . "';\n";
	}
	echo "\n";

	print "var liveIPTable = new Array()\n";
	foreach( outLiveIPTable() as $i){
		echo "liveIPTable.push(new Array(" ,'"'.$i[0].'"' ,',"'.$i[1].'"' ,',"'.$i[2].'"'    , "));\n";
	}
	echo "\n";
}

?>
